"""Order models. Keep in sync with frontend/src/lib/types.ts (Order)."""

from datetime import datetime

from pydantic import BaseModel, Field

from models.shared import AiVerdict, FakeFlag, RobloxProfile


class OrderCreate(BaseModel):
    roblox_username: str = Field(min_length=3, max_length=32)
    robux: int = Field(gt=0)
    payment_method: str
    note: str | None = Field(default=None, max_length=300)
    voucher_code: str | None = Field(default=None, max_length=24)


class OrderOut(BaseModel):
    id: str
    code: str
    user_id: str | None = None
    roblox_username: str
    roblox_profile: RobloxProfile | None = None
    roblox_verified: bool = False
    robux: int
    price_idr: int
    discount_percent: int = 0
    total_idr: int
    voucher_code: str | None = None
    promo_discount_idr: int = 0
    total_coins: int | None = None
    payment_method: str
    status: str
    note: str | None = None
    reject_reason: str | None = None
    proof_file_id: str | None = None
    proof_flags: list[FakeFlag] = []
    ai_verdict: AiVerdict | None = None
    created_at: datetime
    updated_at: datetime
    processed_at: datetime | None = None
