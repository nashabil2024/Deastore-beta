"""Auth models. Keep in sync with frontend/src/lib/types.ts (SessionUser)."""

from datetime import datetime

from pydantic import BaseModel, Field


class RegisterIn(BaseModel):
    username: str = Field(min_length=3, max_length=24, pattern=r"^[A-Za-z0-9_.]+$")
    password: str = Field(min_length=6, max_length=72)
    referral_code: str | None = Field(default=None, max_length=24)


class LoginIn(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    id: str
    username: str
    role: str
    coins: int
    created_at: datetime
