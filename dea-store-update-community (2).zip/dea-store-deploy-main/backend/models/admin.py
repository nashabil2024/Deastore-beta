"""Admin-side models. Keep in sync with frontend/src/lib/types.ts."""

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class PaymentAccount(BaseModel):
    method: str
    name: str
    number: str


class SettingsOut(BaseModel):
    wa_number: str
    payment_accounts: list[PaymentAccount] = []
    # coin_rate remains as a compatibility value (IDR per coin) for older clients.
    coin_rate: float = 1.1
    coin_price_idr_per_100: int = 110
    coin_discount_percent: int = 10
    min_topup_coins: int = 10000
    announcement: str | None = None
    maintenance: bool = False
    qris_image_file_id: str | None = None
    store_name: str = "Dea Store"
    logo_file_id: str | None = None
    hero_title: str = "Top Up Robux Murah & Instan"
    hero_subtitle: str = "Cek username, pilih paket, lalu pesan dengan mudah."
    store_open: bool = True
    store_open_now: bool = True
    opening_hours_enabled: bool = False
    opens_at: str = "08:00"
    closes_at: str = "22:00"
    robux_stock: int | None = None
    robux_stock_available: int | None = None
    custom_robux_price_per_1000_idr: int = 150000


class SettingsIn(BaseModel):
    wa_number: str = Field(default="", max_length=20)
    payment_accounts: list[PaymentAccount] = []
    coin_price_idr_per_100: int = Field(default=110, gt=0, le=100000000)
    coin_discount_percent: int = Field(ge=0, le=50)
    min_topup_coins: int = Field(gt=0)
    announcement: str | None = None
    maintenance: bool = False
    store_name: str = Field(default="Dea Store", min_length=1, max_length=60)
    logo_file_id: str | None = None
    hero_title: str = Field(default="Top Up Robux Murah & Instan", min_length=1, max_length=120)
    hero_subtitle: str = Field(default="Cek username, pilih paket, lalu pesan dengan mudah.", max_length=250)
    store_open: bool = True
    opening_hours_enabled: bool = False
    opens_at: str = Field(default="08:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    closes_at: str = Field(default="22:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    robux_stock: int | None = Field(default=None, ge=0, le=100000000000)
    custom_robux_price_per_1000_idr: int = Field(default=150000, gt=0, le=1000000000)


class StatsOut(BaseModel):
    orders_pending: int
    orders_today: int
    topups_pending: int
    users_count: int
    revenue_idr: int
    robux_sold: int
    coin_circulation: int


class AdjustCoinsIn(BaseModel):
    delta: int
    note: str | None = None


class UserPasswordIn(BaseModel):
    password: str = Field(min_length=6, max_length=72)


class UserRoleIn(BaseModel):
    role: Literal["user", "admin"]


class RejectIn(BaseModel):
    reason: str = Field(min_length=3, max_length=300)


class AdminUserOut(BaseModel):
    id: str
    username: str
    role: str
    coins: int
    created_at: datetime


class AdminLogOut(BaseModel):
    id: str
    admin_username: str
    action: str
    target: str
    detail: str | None = None
    created_at: datetime
