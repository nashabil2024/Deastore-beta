"""Coin top-up models. Keep in sync with frontend/src/lib/types.ts (CoinTopup)."""

from datetime import datetime

from pydantic import BaseModel, Field

from models.shared import AiVerdict, FakeFlag


class TopupCreate(BaseModel):
    coins: int = Field(gt=0)
    payment_method: str


class TopupOut(BaseModel):
    id: str
    code: str
    user_id: str
    coins: int
    amount_idr: int
    payment_method: str
    status: str
    reject_reason: str | None = None
    proof_file_id: str | None = None
    proof_flags: list[FakeFlag] = []
    ai_verdict: AiVerdict | None = None
    created_at: datetime
    processed_at: datetime | None = None
