"""Roblox username detection (server-side proxy for the public Roblox API)."""

from fastapi import APIRouter
from pydantic import BaseModel, Field

from lib.roblox import lookup
from models.shared import LookupOut

router = APIRouter(prefix="/roblox", tags=["roblox"])


class LookupIn(BaseModel):
    username: str = Field(min_length=3, max_length=32)


@router.post("/lookup", response_model=LookupOut)
async def lookup_username(input: LookupIn):
    return LookupOut(**await lookup(input.username))
