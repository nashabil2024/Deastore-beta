import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BadgeCheck, Loader2, Search, TriangleAlert, UserRound, UserX } from "lucide-react";
import { apiPost } from "@/lib/api";
import type { LookupResult } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Props {
  value: string;
  onChange: (v: string) => void;
  onStatus?: (status: "found" | "not_found" | "unavailable" | "idle") => void;
}

export default function RobloxDetector({ value, onChange, onStatus }: Props) {
  const [debounced, setDebounced] = useState("");

  useEffect(() => {
    const t = setTimeout(() => setDebounced(value.trim()), 500);
    return () => clearTimeout(t);
  }, [value]);

  const enabled = debounced.length >= 3;
  const q = useQuery({
    queryKey: ["roblox", debounced],
    queryFn: () => apiPost<LookupResult>("/roblox/lookup", { username: debounced }),
    enabled,
    staleTime: 5 * 60_000,
    retry: false,
  });

  const status = !enabled ? "idle" : q.isFetching ? "idle" : q.data?.status ?? "idle";
  useEffect(() => {
    onStatus?.(status);
  }, [status, onStatus]);

  const profile = q.data?.profile ?? null;

  return (
    <div className="space-y-3" data-testid="roblox-detector-widget">
      <div className="flex gap-2">
        <Input
          data-testid="input-roblox-username"
          aria-label="Username Roblox"
          placeholder="Username Roblox kamu, cth: builderman"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          maxLength={32}
          className="h-12 text-base"
        />
        <Button
          type="button"
          data-testid="btn-detect-username"
          disabled={!enabled || q.isFetching}
          className="h-12"
          onClick={() => q.refetch()}
        >
          {q.isFetching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Cek Akun
        </Button>
      </div>

      {enabled && q.isFetching && (
        <p className="flex items-center gap-2 text-sm text-muted-foreground" data-testid="roblox-detecting">
          <Loader2 className="h-4 w-4 animate-spin text-primary" /> Mendeteksi username di Roblox…
        </p>
      )}

      {q.data?.status === "found" && profile && (
        <div
          className="flex items-center gap-3 rounded-xl border border-emerald-300/60 bg-emerald-50 p-3 dark:border-emerald-500/40 dark:bg-emerald-500/10"
          data-testid="roblox-profile-card"
        >
          {profile.avatar_url ? (
            <img
              src={profile.avatar_url}
              alt={`Avatar Roblox ${profile.display_name ?? profile.username}`}
              className="h-14 w-14 rounded-full border-2 border-emerald-400 bg-white"
              data-testid="roblox-avatar-img"
            />
          ) : (
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-200 dark:bg-emerald-500/20">
              <UserRound className="h-7 w-7 text-emerald-700 dark:text-emerald-300" />
            </div>
          )}
          <div className="min-w-0">
            <p className="flex items-center gap-1 truncate font-heading text-base font-extrabold">
              {profile.display_name ?? profile.username}
              <BadgeCheck className="h-4 w-4 shrink-0 text-emerald-600" />
            </p>
            <p className="truncate text-sm text-muted-foreground" data-testid="roblox-profile-username">
              @{profile.username} · ID {profile.user_id}
            </p>
            <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">
              Akun terdeteksi — aman untuk lanjut
            </p>
          </div>
        </div>
      )}

      {q.data?.status === "not_found" && (
        <p
          className="flex items-center gap-2 rounded-xl border border-red-300/60 bg-red-50 p-3 text-sm font-semibold text-red-700 dark:border-red-500/40 dark:bg-red-500/10 dark:text-red-300"
          data-testid="roblox-not-found"
        >
          <UserX className="h-4 w-4" /> Username tidak ditemukan di Roblox. Periksa lagi ejaannya, ya.
        </p>
      )}

      {q.data?.status === "unavailable" && (
        <p
          className="flex items-center gap-2 rounded-xl border border-amber-300/60 bg-amber-50 p-3 text-sm font-semibold text-amber-700 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
          data-testid="roblox-unavailable-warning"
        >
          <TriangleAlert className="h-4 w-4" /> Roblox sedang tidak bisa dihubungi. Pesanan tetap bisa
          dilanjutkan — pastikan username benar, ya.
        </p>
      )}
    </div>
  );
}
