import { useRef, useState } from "react";
import { ImagePlus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface Props {
  file: File | null;
  onFile: (f: File | null) => void;
  disabled?: boolean;
}

export default function ProofUploader({ file, onFile, disabled }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  function pick(f: File | undefined | null) {
    if (!f) return;
    if (preview) URL.revokeObjectURL(preview);
    setPreview(URL.createObjectURL(f));
    onFile(f);
  }

  function remove() {
    if (preview) URL.revokeObjectURL(preview);
    setPreview(null);
    onFile(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  if (file && preview) {
    return (
      <div
        className="flex items-center gap-3 rounded-xl border border-pink-500/25 bg-card p-3"
        data-testid="proof-preview"
      >
        <img src={preview} alt="Pratinjau bukti pembayaran" className="h-16 w-16 rounded-lg object-cover" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{file.name}</p>
          <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(0)} KB</p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          data-testid="proof-remove-button"
          aria-label="Hapus bukti"
          disabled={disabled}
          onClick={remove}
        >
          <Trash2 className="h-4 w-4 text-destructive" />
        </Button>
      </div>
    );
  }

  return (
    <div
      role="button"
      tabIndex={0}
      data-testid="proof-uploader"
      onClick={() => !disabled && inputRef.current?.click()}
      onKeyDown={(e) => e.key === "Enter" && !disabled && inputRef.current?.click()}
      onDragOver={(e) => {
        e.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragOver(false);
        pick(e.dataTransfer.files?.[0]);
      }}
      className={cn(
        "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-6 text-center transition-all",
        dragOver ? "animate-pulse border-primary bg-primary/5" : "border-pink-500/30 hover:border-primary/60",
        disabled && "pointer-events-none opacity-50",
      )}
    >
      <ImagePlus className="h-8 w-8 text-primary" />
      <p className="text-sm font-semibold">Klik atau seret foto bukti pembayaran</p>
      <p className="text-xs text-muted-foreground">JPG / PNG / WebP, maksimal 5MB</p>
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        data-testid="proof-file-input"
        className="hidden"
        onChange={(e) => pick(e.target.files?.[0])}
      />
    </div>
  );
}
