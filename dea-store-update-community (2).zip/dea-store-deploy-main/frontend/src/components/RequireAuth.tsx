import type { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { useSession } from "@/lib/session";
import SessionUnavailable from "@/components/SessionUnavailable";

export default function RequireAuth({ children, admin = false }: { children: ReactNode; admin?: boolean }) {
  const { data: user, isLoading, isError, isFetching, refetch } = useSession();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center" data-testid="auth-loading">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  if (isError && !user) {
    return <SessionUnavailable onRetry={() => { void refetch(); }} isRetrying={isFetching} />;
  }
  if (!user) {
    return <Navigate to={`/login?next=${encodeURIComponent(location.pathname)}`} replace />;
  }
  if (admin && user.role !== "admin") {
    return <Navigate to="/" replace />;
  }
  return <>{children}</>;
}
