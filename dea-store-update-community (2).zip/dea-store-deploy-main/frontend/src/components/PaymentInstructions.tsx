import type { StoreSettings } from "@/lib/types";
import { fileUrl, formatIDR, PAYMENT_LABELS } from "@/lib/format";
import CopyText from "@/components/CopyText";

export default function PaymentInstructions({ settings, method, total }: { settings?: StoreSettings; method: string; total: number }) {
  if (method === "coin") return null;
  const accounts = (settings?.payment_accounts ?? []).filter((account) => account.method === method);
  const hasQris = method === "qris" && settings?.qris_image_file_id;
  return (
    <div className="space-y-3" data-testid="payment-instructions">
      <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
        <p className="text-xs font-bold uppercase tracking-wide text-primary">Bayar tepat sejumlah ini</p>
        <div className="mt-1 flex flex-wrap items-center gap-2">
          <p className="text-2xl font-extrabold text-primary">{formatIDR(total)}</p>
          <CopyText value={String(total)} label="Salin nominal pembayaran" />
        </div>
        <p className="mt-1 text-xs text-muted-foreground">Jangan ubah nominal agar admin lebih mudah mengecek pembayaran.</p>
      </div>
      {hasQris && (
        <div className="flex flex-col items-center gap-2 rounded-xl border border-pink-500/20 bg-card p-4">
          <img src={fileUrl(settings.qris_image_file_id!)} alt="QRIS Dea Store" className="h-48 w-48 max-w-full rounded-lg object-contain" data-testid="qris-image" />
          <p className="text-center text-xs text-muted-foreground">Scan QRIS ini dengan e-wallet atau m-banking.</p>
        </div>
      )}
      {accounts.map((account) => (
        <div key={account.method + account.number} className="flex items-center justify-between gap-2 rounded-xl border border-pink-500/20 bg-card px-4 py-3">
          <div className="min-w-0">
            <p className="break-words text-xs font-bold uppercase tracking-wide text-primary">{account.name}</p>
            <p className="break-all font-mono text-sm font-semibold">{account.number}</p>
          </div>
          <CopyText value={account.number} label={`Salin nomor ${account.name}`} />
        </div>
      ))}
      {!settings ? (
        <p className="text-sm text-muted-foreground">Rincian pembayaran belum tersedia. Coba muat ulang sebelum mentransfer.</p>
      ) : accounts.length === 0 && !hasQris ? (
        <p className="text-sm text-muted-foreground">Hubungi CS untuk memastikan rekening {PAYMENT_LABELS[method] ?? method} sebelum mentransfer.</p>
      ) : null}
    </div>
  );
}
