import { RefreshCw, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SessionUnavailable({ onRetry, isRetrying = false }: { onRetry: () => void; isRetrying?: boolean }) {
  return (
    <div className="mx-auto flex min-h-[50vh] max-w-lg flex-col items-center justify-center px-4 text-center" role="alert" data-testid="session-unavailable">
      <div className="mb-4 rounded-full bg-secondary p-4 text-muted-foreground">
        <WifiOff className="h-7 w-7" />
      </div>
      <h1 className="text-xl font-bold">Server sedang sulit dihubungi</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Sesi akunmu belum dihapus. Periksa koneksi, lalu coba lagi sebentar.
      </p>
      <Button className="mt-5" onClick={onRetry} disabled={isRetrying}>
        <RefreshCw className={isRetrying ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
        Coba Lagi
      </Button>
    </div>
  );
}
