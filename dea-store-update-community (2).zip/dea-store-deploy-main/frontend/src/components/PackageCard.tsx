import { Badge } from "@/components/ui/badge";
import { formatIDR, formatNumber } from "@/lib/format";
import type { Package } from "@/lib/types";
import { cn } from "@/lib/utils";

interface Props {
  pkg: Package;
  selected?: boolean;
  coinPrice?: number | null;
  onSelect: (pkg: Package) => void;
}

export default function PackageCard({ pkg, selected, coinPrice, onSelect }: Props) {
  return (
    <button
      type="button"
      data-testid={`package-card-${pkg.robux}`}
      onClick={() => onSelect(pkg)}
      aria-pressed={Boolean(selected)}
      className={cn(
        "group relative flex h-full w-full min-w-0 flex-col items-start gap-1 rounded-2xl border p-3 text-left transition-all duration-200 hover:scale-[1.02] hover:border-primary/60 hover:shadow-lg hover:shadow-pink-500/10 active:scale-[0.98] sm:p-4",
        selected ? "border-primary bg-primary/5 ring-2 ring-primary/40" : "border-pink-500/15 bg-card",
      )}
    >
      {pkg.tag && (
        <Badge className="mb-1 h-auto min-h-5 max-w-full whitespace-normal break-words bg-gradient-to-r from-pink-600 to-rose-500 text-white">
          {pkg.tag}
        </Badge>
      )}
      <span className="break-words font-heading text-xl font-extrabold sm:text-2xl">
        {formatNumber(pkg.robux)}{" "}
        <span className="text-sm font-bold text-primary">Robux</span>
      </span>
      <span className="break-all text-base font-bold text-primary sm:text-lg" data-testid={`package-price-${pkg.robux}`}>
        {formatIDR(pkg.price_idr)}
      </span>
      {coinPrice != null && (
        <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
          atau {formatNumber(coinPrice)} Coin
        </span>
      )}
      <span className="text-[11px] text-muted-foreground">Langsung via username Roblox</span>
    </button>
  );
}
