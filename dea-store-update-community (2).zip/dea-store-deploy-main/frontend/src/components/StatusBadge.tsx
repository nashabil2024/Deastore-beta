import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const ORDER_STATUS_META: Record<string, { label: string; className: string }> = {
  menunggu_pembayaran: {
    label: "Menunggu Pembayaran",
    className: "border-amber-300 bg-amber-100 text-amber-800 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-300",
  },
  menunggu_verifikasi: {
    label: "Menunggu Verifikasi",
    className: "border-sky-300 bg-sky-100 text-sky-800 dark:border-sky-500/40 dark:bg-sky-500/15 dark:text-sky-300",
  },
  diproses: {
    label: "Diproses",
    className: "border-pink-300 bg-pink-100 text-pink-800 dark:border-pink-500/40 dark:bg-pink-500/15 dark:text-pink-300",
  },
  selesai: {
    label: "Selesai",
    className: "border-emerald-300 bg-emerald-100 text-emerald-800 dark:border-emerald-500/40 dark:bg-emerald-500/15 dark:text-emerald-300",
  },
  ditolak: {
    label: "Ditolak",
    className: "border-red-300 bg-red-100 text-red-800 dark:border-red-500/40 dark:bg-red-500/15 dark:text-red-300",
  },
};

const TOPUP_STATUS_META: Record<string, { label: string; className: string }> = {
  menunggu_pembayaran: ORDER_STATUS_META.menunggu_pembayaran,
  menunggu_verifikasi: ORDER_STATUS_META.menunggu_verifikasi,
  disetujui: ORDER_STATUS_META.selesai,
  ditolak: ORDER_STATUS_META.ditolak,
};

export function OrderStatusBadge({ status }: { status: string }) {
  const meta = ORDER_STATUS_META[status] ?? { label: status, className: "" };
  return (
    <Badge variant="outline" className={meta.className} data-testid={`order-status-badge-${status}`}>
      {meta.label}
    </Badge>
  );
}

export function TopupStatusBadge({ status }: { status: string }) {
  const meta = TOPUP_STATUS_META[status] ?? { label: status, className: "" };
  return (
    <Badge variant="outline" className={meta.className} data-testid={`topup-status-badge-${status}`}>
      {meta.label}
    </Badge>
  );
}

const RISK_META: Record<string, { label: string; className: string }> = {
  low: {
    label: "Risiko Rendah",
    className: "border-emerald-300 bg-emerald-100 text-emerald-800 dark:border-emerald-500/40 dark:bg-emerald-500/15 dark:text-emerald-300",
  },
  medium: {
    label: "Risiko Sedang",
    className: "border-amber-300 bg-amber-100 text-amber-800 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-300",
  },
  high: {
    label: "Risiko Tinggi",
    className: "border-red-300 bg-red-100 text-red-800 dark:border-red-500/40 dark:bg-red-500/15 dark:text-red-300",
  },
};

export function RiskBadge({ risk, duplicate }: { risk: string | null; duplicate: boolean }) {
  if (duplicate) {
    return (
      <Badge className="border-red-300 bg-red-600 text-white hover:bg-red-600" data-testid="risk-badge-duplicate">
        Duplikat Terdeteksi
      </Badge>
    );
  }
  if (!risk) return null;
  const meta = RISK_META[risk];
  if (!meta) return null;
  return (
    <Badge variant="outline" className={cn(meta.className)} data-testid={`risk-badge-${risk}`}>
      {meta.label}
    </Badge>
  );
}
