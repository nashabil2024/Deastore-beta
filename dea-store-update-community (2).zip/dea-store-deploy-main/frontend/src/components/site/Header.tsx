import { useEffect, useRef, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useTheme } from "next-themes";
import {
  ChevronDown,
  Coins,
  Headset,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  Package,
  Gift,
  Search,
  Shield,
  ShoppingCart,
  Sun,
  UserRound,
} from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useEndSession, useSession } from "@/lib/session";
import { fileUrl, formatNumber, waLink } from "@/lib/format";
import { apiGet } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import type { StoreSettings } from "@/lib/types";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Top Up", icon: ShoppingCart, testid: "nav-link-topup" },
  { to: "/track", label: "Cek Pesanan", icon: Search, testid: "nav-link-track" },
  { to: "/orders", label: "Pesanan Saya", icon: Package, testid: "nav-link-my-orders" },
  { to: "/dashboard", label: "Saldo Coin", icon: Coins, testid: "nav-link-dashboard" },
  { to: "/member", label: "Member Club", icon: Gift, testid: "nav-link-member" },
];

export default function Header() {
  const { data: user } = useSession();
  const { data: settings } = useQuery({ queryKey: ["settings"], queryFn: () => apiGet<StoreSettings>("/settings"), refetchInterval: 10000 });
  const endSession = useEndSession();
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();
  const [mounted, setMounted] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const profileMenuRef = useRef<HTMLDivElement>(null);
  const storeName = settings?.store_name || "Dea Store";
  const csLink = settings?.wa_number ? waLink(settings.wa_number, "Halo, saya mau bertanya tentang layanan Dea Store.") : null;

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!profileOpen) return;
    const closeOutside = (event: MouseEvent) => {
      if (!profileMenuRef.current?.contains(event.target as Node)) setProfileOpen(false);
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setProfileOpen(false);
    };
    document.addEventListener("mousedown", closeOutside);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("mousedown", closeOutside);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [profileOpen]);

  return (
    <header
      className="sticky top-0 z-40 border-b border-pink-500/15 bg-background/85 backdrop-blur-md"
      data-testid="site-header"
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-2 px-3 sm:gap-3 sm:px-4">
        <Link to="/" data-testid="header-logo-link" className="flex shrink-0 items-center gap-2">
          <img src={settings?.logo_file_id ? fileUrl(settings.logo_file_id) : "/logo.svg"} alt={`Logo ${storeName}`} className="h-9 w-9 rounded-lg object-contain drop-shadow" />
          <span className="max-w-20 truncate font-heading text-lg font-extrabold tracking-tight sm:max-w-none sm:text-xl">{storeName}</span>
        </Link>

        <nav className="hidden items-center gap-1 xl:flex">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              data-testid={n.testid}
              className={({ isActive }) =>
                cn(
                  "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                  isActive ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground",
                )
              }
            >
              {n.label}
            </NavLink>
          ))}
          {csLink ? (
            <a href={csLink} target="_blank" rel="noreferrer" data-testid="nav-link-cs" className="rounded-full px-3 py-1.5 text-sm font-semibold text-emerald-700 hover:bg-emerald-500/10 dark:text-emerald-400">
              <Headset className="mr-1 inline h-4 w-4" /> CS
            </a>
          ) : (
            <span title="Atur nomor WhatsApp di Panel Admin > Pengaturan" className="rounded-full px-3 py-1.5 text-sm font-semibold text-muted-foreground" data-testid="nav-link-cs">
              <Headset className="mr-1 inline h-4 w-4" /> CS
            </span>
          )}
          {user?.role === "admin" && (
            <NavLink
              to="/admin"
              data-testid="nav-link-admin"
              className={({ isActive }) =>
                cn(
                  "rounded-full px-3 py-1.5 text-sm font-bold transition-colors",
                  isActive ? "bg-primary/10 text-primary" : "text-amber-600 hover:text-primary dark:text-amber-400",
                )
              }
            >
              Admin
            </NavLink>
          )}
        </nav>

        <div className="flex items-center gap-2">
          {user && (
            <Link
              to="/dashboard"
              data-testid="header-coin-balance"
              className="hidden items-center gap-1.5 rounded-full border border-amber-300/60 bg-amber-100 px-3 py-1.5 text-sm font-bold text-amber-700 transition-colors hover:bg-amber-200 sm:flex dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-300"
            >
              <Coins className="h-4 w-4" />
              {formatNumber(user.coins)}
            </Link>
          )}

          <button
            type="button"
            data-testid="theme-toggle-button"
            aria-label="Ganti tema terang/gelap"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-pink-500/20 text-muted-foreground transition-colors hover:text-primary"
          >
            {mounted && theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>

          {user ? (
            <div className="relative" ref={profileMenuRef}>
              <button
                type="button"
                data-testid="user-menu-button"
                aria-label={`Buka menu profil ${user.username}`}
                aria-expanded={profileOpen}
                aria-haspopup="menu"
                onClick={() => setProfileOpen((open) => !open)}
                className={cn(buttonVariants({ variant: "outline" }), "gap-2 rounded-full")}
              >
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-extrabold text-primary-foreground">
                  {user.username.charAt(0).toUpperCase()}
                </span>
                <span className="hidden max-w-24 truncate text-sm sm:inline">{user.username}</span>
                <ChevronDown className={cn("hidden h-4 w-4 transition-transform sm:block", profileOpen && "rotate-180")} />
              </button>
              {profileOpen && (
                <div
                  className="absolute right-0 z-[60] mt-2 w-64 rounded-xl border border-pink-500/20 bg-card p-2 text-card-foreground shadow-xl"
                  data-testid="user-profile-menu"
                  aria-label="Menu profil"
                >
                  <div className="rounded-lg bg-secondary/70 px-3 py-2.5" data-testid="user-menu-username">
                    <p className="font-bold">{user.username}</p>
                    <p className="text-xs capitalize text-muted-foreground">{user.role === "admin" ? "Administrator" : "Member"}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-sm font-semibold text-amber-700 dark:text-amber-300">
                      <Coins className="h-4 w-4" /> Saldo {formatNumber(user.coins)} coin
                    </p>
                  </div>
                  <div className="mt-1 space-y-0.5">
                    <Link
                      to="/dashboard"
                      role="menuitem"
                      data-testid="menu-dashboard-link"
                      onClick={() => setProfileOpen(false)}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-accent"
                    >
                      <LayoutDashboard className="h-4 w-4" /> Dashboard & Top-Up Coin
                    </Link>
                    <Link
                      to="/orders"
                      role="menuitem"
                      data-testid="menu-orders-link"
                      onClick={() => setProfileOpen(false)}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-accent"
                    >
                      <Package className="h-4 w-4" /> Riwayat Pesanan
                    </Link>
                    <Link
                      to="/track"
                      role="menuitem"
                      data-testid="menu-track-link"
                      onClick={() => setProfileOpen(false)}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-accent"
                    >
                      <Search className="h-4 w-4" /> Cek Status Pesanan
                    </Link>
                {user.role === "admin" && (
                      <Link
                        to="/admin"
                        role="menuitem"
                        data-testid="menu-admin-link"
                        onClick={() => setProfileOpen(false)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-accent"
                      >
                        <Shield className="h-4 w-4" /> Panel Admin
                      </Link>
                )}
                    <button
                      type="button"
                      role="menuitem"
                      data-testid="menu-logout-button"
                      onClick={() => {
                        setProfileOpen(false);
                        void endSession().then(() => navigate("/"));
                      }}
                      className="mt-1 flex w-full items-center gap-2 rounded-lg border-t border-border px-3 py-2 text-left text-sm text-destructive hover:bg-destructive/10"
                    >
                      <LogOut className="h-4 w-4" /> Keluar dari akun
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="hidden items-center gap-2 sm:flex">
              <Link
                to="/login"
                data-testid="header-login-button"
                className={buttonVariants({ variant: "ghost", size: "sm" })}
              >
                Masuk
              </Link>
              <Link
                to="/register"
                data-testid="header-register-button"
                className={buttonVariants({ size: "sm" })}
              >
                Daftar
              </Link>
            </div>
          )}

          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger
              className={cn(buttonVariants({ variant: "outline", size: "icon" }), "xl:hidden")}
              data-testid="mobile-menu-button"
              aria-label="Buka menu"
            >
              <Menu className="h-5 w-5" />
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <SheetTitle className="flex items-center gap-2">
                <img src={settings?.logo_file_id ? fileUrl(settings.logo_file_id) : "/logo.svg"} alt="" className="h-7 w-7 rounded-md object-contain" /> {storeName}
              </SheetTitle>
              <div className="mt-4 flex flex-col gap-1">
                {NAV.map((n) => (
                  <NavLink
                    key={n.to}
                    to={n.to}
                    data-testid={`${n.testid}-mobile`}
                    onClick={() => setMobileOpen(false)}
                    className={({ isActive }) =>
                      cn(
                        "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold",
                        isActive ? "bg-primary/10 text-primary" : "text-foreground/80 hover:bg-accent",
                      )
                    }
                  >
                    <n.icon className="h-4 w-4" /> {n.label}
                  </NavLink>
                ))}
                {csLink ? (
                  <a href={csLink} target="_blank" rel="noreferrer" data-testid="nav-link-cs-mobile" onClick={() => setMobileOpen(false)} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-emerald-700 hover:bg-emerald-500/10 dark:text-emerald-400">
                    <Headset className="h-4 w-4" /> Hubungi CS
                  </a>
                ) : (
                  <span title="Atur nomor WhatsApp di Panel Admin > Pengaturan" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-muted-foreground" data-testid="nav-link-cs-mobile">
                    <Headset className="h-4 w-4" /> CS belum diatur
                  </span>
                )}
                {user?.role === "admin" && (
                  <NavLink
                    to="/admin"
                    data-testid="nav-link-admin-mobile"
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-bold text-amber-600 hover:bg-accent"
                  >
                    <Shield className="h-4 w-4" /> Panel Admin
                  </NavLink>
                )}
                {!user && (
                  <div className="mt-3 flex flex-col gap-2">
                    <Link
                      to="/login"
                      data-testid="header-login-button-mobile"
                      onClick={() => setMobileOpen(false)}
                      className={buttonVariants({ variant: "outline" })}
                    >
                      Masuk
                    </Link>
                    <Link
                      to="/register"
                      data-testid="header-register-button-mobile"
                      onClick={() => setMobileOpen(false)}
                      className={buttonVariants()}
                    >
                      <UserRound className="h-4 w-4" /> Daftar Sekarang
                    </Link>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
