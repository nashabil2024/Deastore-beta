import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiGet } from "@/lib/api";
import { fileUrl, waLink } from "@/lib/format";
import type { StoreSettings } from "@/lib/types";

export default function Footer() {
  const { data: settings } = useQuery({ queryKey: ["settings"], queryFn: () => apiGet<StoreSettings>("/settings"), refetchInterval: 10000 });
  const storeName = settings?.store_name || "Dea Store";
  return (
    <footer className="border-t border-pink-500/15 bg-card/60" data-testid="site-footer">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-3">
        <div>
          <div className="flex items-center gap-2">
            <img src={settings?.logo_file_id ? fileUrl(settings.logo_file_id) : "/logo.svg"} alt={`Logo ${storeName}`} className="h-8 w-8 rounded-lg object-contain" />
            <span className="font-heading text-lg font-extrabold">{storeName}</span>
          </div>
          <p className="mt-3 max-w-xs text-sm text-muted-foreground">
            Pusat top up Robux via username Roblox — murah, cepat, dan aman. Pembayaran QRIS,
            e-wallet, transfer bank, atau Saldo Coin.
          </p>
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase tracking-wider text-primary">Menu</h3>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/order" className="hover:text-primary" data-testid="footer-link-order">Top Up Robux</Link></li>
            <li><Link to="/track" className="hover:text-primary" data-testid="footer-link-track">Cek Pesanan</Link></li>
            <li><Link to="/dashboard" className="hover:text-primary" data-testid="footer-link-dashboard">Top-Up Saldo Coin</Link></li>
            <li><Link to="/register" className="hover:text-primary" data-testid="footer-link-register">Daftar Akun</Link></li>
            {settings?.wa_number && <li><a href={waLink(settings.wa_number, "Halo, saya mau bertanya tentang layanan Dea Store.")} target="_blank" rel="noreferrer" className="hover:text-primary" data-testid="footer-link-cs">Customer Service</a></li>}
          </ul>
        </div>
        <div>
          <h3 className="text-sm font-bold uppercase tracking-wider text-primary">Catatan</h3>
          <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
            Dea Store bukan afiliasi resmi Roblox Corporation. Robux merupakan merek dagang
            Roblox Corporation. Pastikan username Roblox benar sebelum membayar — Robux yang
            sudah terkirim ke akun yang salah tidak dapat ditarik.
          </p>
        </div>
      </div>
      <div className="border-t border-pink-500/10 py-4 text-center text-xs text-muted-foreground">
        Dibuat dengan <Heart className="inline h-3 w-3 text-primary" /> — © {new Date().getFullYear()} Dea Store
      </div>
    </footer>
  );
}
