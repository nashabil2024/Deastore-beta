import { useState } from "react";
import { Link, Navigate, useNavigate, useSearchParams } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Coins, Loader2, LockKeyhole, ShieldCheck } from "lucide-react";
import { ApiError, apiPost } from "@/lib/api";
import type { SessionUser } from "@/lib/types";
import { useBeginSession, useSession } from "@/lib/session";
import SessionUnavailable from "@/components/SessionUnavailable";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function AuthShell({ children, title, description }: { children: React.ReactNode; title: string; description: string }) {
  return (
    <div className="mx-auto grid max-w-5xl items-stretch gap-0 px-4 py-10 lg:grid-cols-2 lg:gap-10">
      <div className="relative hidden overflow-hidden rounded-3xl lg:block">
        <img src="/hero.png" alt="Dea Store" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#180D25]/95 via-[#180D25]/40 to-transparent" />
        <div className="absolute bottom-0 p-8 text-white">
          <h2 className="text-2xl">Top Up Robux paling gampang!</h2>
          <p className="mt-2 text-sm text-pink-200">
            Deteksi username otomatis, bayar pakai QRIS / e-wallet / bank, atau Saldo Coin dengan diskon 10%.
          </p>
        </div>
      </div>
      <Card className="border-pink-500/20" data-testid="auth-card">
        <CardHeader>
          <CardTitle className="text-2xl">{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent>{children}</CardContent>
      </Card>
    </div>
  );
}

export default function LoginPage() {
  const [params] = useSearchParams();
  const requestedNext = params.get("next");
  const next = requestedNext?.startsWith("/") && !requestedNext.startsWith("//") && !["/login", "/register"].includes(requestedNext)
    ? requestedNext
    : null;
  const navigate = useNavigate();
  const beginSession = useBeginSession();
  const { data: currentUser, isLoading: sessionLoading, isError: sessionError, isFetching: sessionFetching, refetch: refetchSession } = useSession();
  const qc = useQueryClient();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const login = useMutation({
    mutationFn: () => apiPost<SessionUser>("/auth/login", { username, password }),
    onSuccess: (u) => {
      beginSession(u);
      toast.success(`Selamat datang kembali, ${u.username}!`);
      navigate(next || (u.role === "admin" ? "/admin" : "/dashboard"), { replace: true });
    },
    onError: (e) =>
      toast.error(e instanceof ApiError ? (e.detail() ?? "Login gagal") : "Login gagal"),
  });

  if (sessionLoading) {
    return <div className="flex min-h-[50vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }
  if (sessionError && !currentUser) {
    return <SessionUnavailable onRetry={() => { void refetchSession(); }} isRetrying={sessionFetching} />;
  }
  if (currentUser) {
    return <Navigate to={currentUser.role === "admin" ? "/admin" : "/dashboard"} replace />;
  }

  return (
    <AuthShell title="Masuk ke Dea Store" description="Bayar pakai Saldo Coin dan pantau semua pesananmu.">
      <form
        className="space-y-4"
        data-testid="login-form"
        onSubmit={(e) => {
          e.preventDefault();
          login.mutate();
        }}
      >
        <div className="space-y-2">
          <Label htmlFor="login-username">Username</Label>
          <Input
            id="login-username"
            data-testid="login-username-input"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            minLength={3}
            autoComplete="username"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="login-password">Password</Label>
          <Input
            id="login-password"
            data-testid="login-password-input"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
          />
        </div>
        <Button type="submit" className="w-full" size="lg" data-testid="login-submit-button" disabled={login.isPending}>
          {login.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <LockKeyhole className="h-4 w-4" />}
          Masuk
        </Button>
        <p className="text-center text-sm text-muted-foreground">
          Belum punya akun?{" "}
          <Link to="/register" data-testid="login-to-register-link" className="font-bold text-primary hover:underline">
            Daftar gratis
          </Link>
        </p>
        <div className="flex items-start gap-2 rounded-xl bg-amber-500/10 p-3 text-xs text-amber-700 dark:text-amber-300">
          <Coins className="mt-0.5 h-4 w-4 shrink-0" />
          Akun coin-mu terlindungi sesi aman (cookie httpOnly) — dan setiap transaksi diverifikasi AI.
          <ShieldCheck className="hidden" />
        </div>
      </form>
    </AuthShell>
  );
}
