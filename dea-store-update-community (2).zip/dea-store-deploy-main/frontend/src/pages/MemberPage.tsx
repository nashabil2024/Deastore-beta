import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Bell, Check, Crown, Gift, Link2, Medal, TicketPercent, Users } from "lucide-react";
import { apiGet, apiPost } from "@/lib/api";
import { Button, buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";

type CommunityData = {
  reward_points: number;
  tier: { name: string; next: string | null; minimum: number };
  referral_code: string;
  referral_count: number;
  unread_notifications: number;
  notifications: { id: string; title: string; message: string; kind: string; read: boolean; created_at: string }[];
  joined_giveaways: string[];
};
type Voucher = { code: string; kind: string; value: number; min_order: number; expires_at: string | null };
type Giveaway = { id: string; title: string; description: string; prize: string; ends_at: string | null; participants: number };

export default function MemberPage() {
  const qc = useQueryClient();
  const me = useQuery({ queryKey: ["community", "me"], queryFn: () => apiGet<CommunityData>("/community/me"), refetchInterval: 15000 });
  const vouchers = useQuery({ queryKey: ["community", "vouchers"], queryFn: () => apiGet<Voucher[]>("/community/vouchers") });
  const giveaways = useQuery({ queryKey: ["community", "giveaways"], queryFn: () => apiGet<Giveaway[]>("/community/giveaways") });
  const join = useMutation({
    mutationFn: (id: string) => apiPost<{ message: string }>(`/community/giveaways/${id}/join`),
    onSuccess: (r) => { toast.success(r.message); qc.invalidateQueries({ queryKey: ["community"] }); },
    onError: () => toast.error("Tidak bisa mengikuti giveaway. Pastikan kamu sudah login."),
  });
  const markRead = useMutation({
    mutationFn: (id: string) => apiPost(`/community/notifications/${id}/read`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["community", "me"] }),
  });
  const referralUrl = `${window.location.origin}/register?ref=${me.data?.referral_code ?? ""}`;
  const copyReferral = async () => {
    try { await navigator.clipboard.writeText(referralUrl); toast.success("Link referral berhasil disalin"); }
    catch { toast.error("Gagal menyalin link referral"); }
  };

  return <div className="mx-auto max-w-6xl space-y-6 px-4 py-8">
    <div><h1 className="text-3xl font-extrabold">DeaStore Member Club</h1><p className="mt-1 text-sm text-muted-foreground">Kumpulkan poin, ajak teman, ikuti giveaway, dan nikmati promo member.</p></div>
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Card className="border-pink-500/20"><CardHeader className="pb-2"><CardDescription className="flex items-center gap-2"><Medal className="h-4 w-4"/> DeaPoints</CardDescription><CardTitle className="text-3xl">{me.data?.reward_points?.toLocaleString("id-ID") ?? "—"}</CardTitle></CardHeader><CardContent className="text-xs text-muted-foreground">Poin dari pesanan yang selesai.</CardContent></Card>
      <Card className="border-pink-500/20"><CardHeader className="pb-2"><CardDescription className="flex items-center gap-2"><Crown className="h-4 w-4"/> Member Level</CardDescription><CardTitle className="text-3xl">{me.data?.tier.name ?? "—"}</CardTitle></CardHeader><CardContent className="text-xs text-muted-foreground">{me.data?.tier.next ? `Target ${me.data.tier.minimum.toLocaleString("id-ID")} poin untuk ${me.data.tier.next}` : "Level tertinggi tercapai!"}</CardContent></Card>
      <Card className="border-pink-500/20"><CardHeader className="pb-2"><CardDescription className="flex items-center gap-2"><Users className="h-4 w-4"/> Teman Diundang</CardDescription><CardTitle className="text-3xl">{me.data?.referral_count ?? "—"}</CardTitle></CardHeader><CardContent className="text-xs text-muted-foreground">Teman yang mendaftar memakai kode kamu.</CardContent></Card>
      <Card className="border-pink-500/20"><CardHeader className="pb-2"><CardDescription className="flex items-center gap-2"><Bell className="h-4 w-4"/> Notifikasi</CardDescription><CardTitle className="text-3xl">{me.data?.unread_notifications ?? "—"}</CardTitle></CardHeader><CardContent className="text-xs text-muted-foreground">Notifikasi yang belum dibaca.</CardContent></Card>
    </div>
    <Card className="border-pink-500/20"><CardHeader><CardTitle>Keuntungan Member Club</CardTitle><CardDescription>Semakin tinggi level, semakin besar poin yang kamu dapatkan dari pesanan selesai.</CardDescription></CardHeader><CardContent className="grid gap-3 sm:grid-cols-3"><div className="rounded-xl border p-3"><p className="font-bold">Bronze</p><p className="text-sm text-muted-foreground">0–1.499 poin · 1x poin</p></div><div className="rounded-xl border p-3"><p className="font-bold">Silver</p><p className="text-sm text-muted-foreground">1.500–4.999 poin · bonus 10%</p></div><div className="rounded-xl border p-3"><p className="font-bold">Gold</p><p className="text-sm text-muted-foreground">5.000+ poin · bonus 25%</p></div></CardContent></Card>
    <div className="grid gap-5 lg:grid-cols-2">
      <Card className="border-pink-500/20"><CardHeader><CardTitle className="flex items-center gap-2"><Link2 className="h-5 w-5 text-primary"/> Referral System</CardTitle><CardDescription>Ajak teman bergabung ke DeaStore. Bonus 100 DeaPoints diberikan setelah pesanan pertama teman selesai.</CardDescription></CardHeader><CardContent className="space-y-3"><div className="rounded-xl bg-secondary p-3"><p className="text-xs text-muted-foreground">Kode referral kamu</p><p className="font-mono text-xl font-bold">{me.data?.referral_code ?? "Memuat…"}</p></div><Button className="w-full" onClick={copyReferral} disabled={!me.data?.referral_code}>Salin Link Referral</Button></CardContent></Card>
      <Card className="border-pink-500/20"><CardHeader><CardTitle className="flex items-center gap-2"><TicketPercent className="h-5 w-5 text-primary"/> Voucher & Promo</CardTitle><CardDescription>Gunakan kode promo yang tersedia pada halaman pemesanan.</CardDescription></CardHeader><CardContent className="space-y-3">{vouchers.data?.length ? vouchers.data.map(v => <div key={v.code} className="flex items-center justify-between gap-3 rounded-xl border p-3"><div><p className="font-mono font-bold">{v.code}</p><p className="text-xs text-muted-foreground">{v.kind === "percent" ? `Diskon ${v.value}%` : `Potongan Rp${v.value.toLocaleString("id-ID")}`} · Min. Rp{v.min_order.toLocaleString("id-ID")}</p></div><Badge variant="secondary">Aktif</Badge></div>) : <p className="text-sm text-muted-foreground">Belum ada voucher aktif.</p>}</CardContent></Card>
    </div>
    <Card className="border-pink-500/20"><CardHeader><CardTitle className="flex items-center gap-2"><Gift className="h-5 w-5 text-primary"/> Giveaway Center</CardTitle><CardDescription>Ikuti giveaway aktif dan pantau informasi hadiahnya.</CardDescription></CardHeader><CardContent className="grid gap-3 md:grid-cols-2">{giveaways.data?.length ? giveaways.data.map(g => { const joined = me.data?.joined_giveaways.includes(g.id) ?? false; return <div key={g.id} className="rounded-xl border p-4"><div className="flex items-start justify-between gap-2"><h3 className="font-bold">{g.title}</h3><Badge variant="secondary">{g.participants} peserta</Badge></div><p className="mt-1 text-sm text-muted-foreground">{g.description}</p><p className="mt-3 text-sm font-semibold">Hadiah: {g.prize}</p><Button className="mt-3 w-full" variant={joined ? "outline" : "default"} disabled={joined || join.isPending} onClick={() => join.mutate(g.id)}>{joined ? <><Check className="mr-2 h-4 w-4"/> Sudah Ikut</> : "Ikuti Giveaway"}</Button></div>; }) : <p className="text-sm text-muted-foreground">Belum ada giveaway aktif.</p>}</CardContent></Card>
    <Card className="border-pink-500/20"><CardHeader><CardTitle className="flex items-center gap-2"><Bell className="h-5 w-5 text-primary"/> Notifikasi Otomatis</CardTitle><CardDescription>Update transaksi, poin, referral, dan giveaway.</CardDescription></CardHeader><CardContent className="space-y-2">{me.data?.notifications.length ? me.data.notifications.map(n => <div key={n.id} className="flex items-start justify-between gap-3 rounded-xl border p-3"><div><p className="font-semibold">{n.title} {!n.read && <Badge className="ml-1">Baru</Badge>}</p><p className="mt-1 text-sm text-muted-foreground">{n.message}</p><p className="mt-1 text-xs text-muted-foreground">{new Date(n.created_at).toLocaleString("id-ID")}</p></div>{!n.read && <Button size="icon-sm" variant="ghost" aria-label="Tandai dibaca" onClick={() => markRead.mutate(n.id)}><Check className="h-4 w-4"/></Button>}</div>) : <p className="text-sm text-muted-foreground">Belum ada notifikasi.</p>}</CardContent></Card>
    <div className="flex flex-wrap gap-2"><Link to="/orders" className={buttonVariants({ variant: "outline" })}>Lihat Pesanan Saya</Link><Link to="/track" className={buttonVariants({ variant: "outline" })}>Lacak Pesanan</Link></div>
  </div>;
}
