import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiGet, apiPatch, apiPost } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type Voucher = { id: string; code: string; kind: "percent" | "fixed"; value: number; min_order: number; max_uses: number | null; uses: number; active: boolean };
type Giveaway = { id: string; title: string; description: string; prize: string; ends_at: string | null; active: boolean };

export default function CommunityAdminTab() {
  const qc = useQueryClient();
  const [code, setCode] = useState(""); const [kind, setKind] = useState<"percent" | "fixed">("percent"); const [value, setValue] = useState("10"); const [minOrder, setMinOrder] = useState("0"); const [maxUses, setMaxUses] = useState("");
  const [title, setTitle] = useState(""); const [description, setDescription] = useState(""); const [prize, setPrize] = useState(""); const [endsAt, setEndsAt] = useState("");
  const vouchers = useQuery({ queryKey: ["community", "admin", "vouchers"], queryFn: () => apiGet<Voucher[]>("/community/admin/vouchers") });
  const giveaways = useQuery({ queryKey: ["community", "admin", "giveaways"], queryFn: () => apiGet<Giveaway[]>("/community/admin/giveaways") });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["community"] }); };
  const createVoucher = useMutation({ mutationFn: () => apiPost("/community/admin/vouchers", { code, kind, value: Number(value), min_order: Number(minOrder), max_uses: maxUses ? Number(maxUses) : null, active: true }), onSuccess: () => { toast.success("Voucher berhasil dibuat"); setCode(""); refresh(); }, onError: () => toast.error("Gagal membuat voucher. Periksa kode dan nilainya.") });
  const createGiveaway = useMutation({ mutationFn: () => apiPost("/community/admin/giveaways", { title, description, prize, ends_at: endsAt || null, active: true }), onSuccess: () => { toast.success("Giveaway berhasil dibuat"); setTitle(""); setDescription(""); setPrize(""); setEndsAt(""); refresh(); }, onError: () => toast.error("Gagal membuat giveaway") });
  const toggle = useMutation({ mutationFn: ({ path, active }: { path: string; active: boolean }) => apiPatch(path, { active }), onSuccess: refresh, onError: () => toast.error("Gagal mengubah status") });
  return <div className="space-y-5">
    <div className="grid gap-5 lg:grid-cols-2">
      <Card><CardHeader><CardTitle>Tambah Voucher</CardTitle><CardDescription>Buat kode diskon untuk pelanggan. Kode akan tersedia di halaman Member Club.</CardDescription></CardHeader><CardContent className="space-y-3">
        <div className="space-y-1"><Label>Kode voucher</Label><Input value={code} onChange={e => setCode(e.target.value.toUpperCase())} placeholder="DEAHEMAT" maxLength={24}/></div>
        <div className="grid grid-cols-2 gap-3"><div className="space-y-1"><Label>Tipe</Label><select className="h-10 w-full rounded-md border bg-background px-3 text-sm" value={kind} onChange={e => setKind(e.target.value as "percent" | "fixed")}><option value="percent">Persentase (%)</option><option value="fixed">Potongan Rupiah</option></select></div><div className="space-y-1"><Label>Nilai diskon</Label><Input type="number" min="1" value={value} onChange={e => setValue(e.target.value)}/></div></div>
        <div className="grid grid-cols-2 gap-3"><div className="space-y-1"><Label>Minimal belanja (Rp)</Label><Input type="number" min="0" value={minOrder} onChange={e => setMinOrder(e.target.value)}/></div><div className="space-y-1"><Label>Batas pemakaian (kosong = tanpa batas)</Label><Input type="number" min="1" value={maxUses} onChange={e => setMaxUses(e.target.value)}/></div></div>
        <Button className="w-full" disabled={!code.trim() || createVoucher.isPending} onClick={() => createVoucher.mutate()}>Buat Voucher</Button>
      </CardContent></Card>
      <Card><CardHeader><CardTitle>Buat Giveaway</CardTitle><CardDescription>Publikasikan giveaway di halaman Member Club.</CardDescription></CardHeader><CardContent className="space-y-3">
        <div className="space-y-1"><Label>Nama giveaway</Label><Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Giveaway Akhir Tahun" maxLength={100}/></div>
        <div className="space-y-1"><Label>Deskripsi</Label><Input value={description} onChange={e => setDescription(e.target.value)} placeholder="Cara mengikuti giveaway..." maxLength={1000}/></div>
        <div className="space-y-1"><Label>Hadiah</Label><Input value={prize} onChange={e => setPrize(e.target.value)} placeholder="2.000 Robux" maxLength={120}/></div>
        <div className="space-y-1"><Label>Tanggal berakhir (opsional)</Label><Input type="datetime-local" value={endsAt} onChange={e => setEndsAt(e.target.value)}/></div>
        <Button className="w-full" disabled={!title.trim() || !prize.trim() || createGiveaway.isPending} onClick={() => createGiveaway.mutate()}>Publikasikan Giveaway</Button>
      </CardContent></Card>
    </div>
    <Card><CardHeader><CardTitle>Daftar Voucher</CardTitle></CardHeader><CardContent className="space-y-2">{vouchers.data?.length ? vouchers.data.map(v => <div key={v.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3"><div><p className="font-mono font-bold">{v.code}</p><p className="text-xs text-muted-foreground">{v.kind === "percent" ? `${v.value}%` : `Rp${v.value.toLocaleString("id-ID")}`} · digunakan {v.uses}{v.max_uses ? `/${v.max_uses}` : " kali"}</p></div><div className="flex items-center gap-2"><Badge variant={v.active ? "default" : "secondary"}>{v.active ? "Aktif" : "Nonaktif"}</Badge><Button size="sm" variant="outline" onClick={() => toggle.mutate({ path: `/community/admin/vouchers/${v.id}?active=${!v.active}`, active: !v.active })}>{v.active ? "Nonaktifkan" : "Aktifkan"}</Button></div></div>) : <p className="text-sm text-muted-foreground">Belum ada voucher.</p>}</CardContent></Card>
    <Card><CardHeader><CardTitle>Daftar Giveaway</CardTitle></CardHeader><CardContent className="space-y-2">{giveaways.data?.length ? giveaways.data.map(g => <div key={g.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3"><div><p className="font-semibold">{g.title}</p><p className="text-xs text-muted-foreground">Hadiah: {g.prize}</p></div><div className="flex items-center gap-2"><Badge variant={g.active ? "default" : "secondary"}>{g.active ? "Aktif" : "Nonaktif"}</Badge><Button size="sm" variant="outline" onClick={() => toggle.mutate({ path: `/community/admin/giveaways/${g.id}?active=${!g.active}`, active: !g.active })}>{g.active ? "Tutup" : "Aktifkan"}</Button></div></div>) : <p className="text-sm text-muted-foreground">Belum ada giveaway.</p>}</CardContent></Card>
  </div>;
}
