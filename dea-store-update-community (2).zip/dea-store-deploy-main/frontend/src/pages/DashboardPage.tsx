import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Coins, Loader2, MessageCircle, Package, Send, Wallet } from "lucide-react";
import { ApiError, apiGet, apiPost, apiUpload } from "@/lib/api";
import type { CoinTopup, StoreSettings } from "@/lib/types";
import {
  fileUrl,
  formatDateTime,
  formatIDR,
  formatNumber,
  MANUAL_METHODS,
  PAYMENT_LABELS,
  topupWaText,
  waLink,
} from "@/lib/format";
import { useSession } from "@/lib/session";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import ProofUploader from "@/components/ProofUploader";
import CopyText from "@/components/CopyText";
import { TopupStatusBadge } from "@/components/StatusBadge";
import { cn } from "@/lib/utils";

const PRESETS = [10000, 25000, 50000, 100000, 200000];

export default function DashboardPage() {
  const { data: user } = useSession();
  const qc = useQueryClient();
  const [params, setParams] = useSearchParams();
  const topupPanel = useRef<HTMLDivElement>(null);
  const [coins, setCoins] = useState<number>(10000);
  const [method, setMethod] = useState<string>("qris");
  const [active, setActive] = useState<CoinTopup | null>(null);
  const [file, setFile] = useState<File | null>(null);

  const { data: settings } = useQuery({ queryKey: ["settings"], queryFn: () => apiGet<StoreSettings>("/settings"), refetchInterval: 10000 });
  const topupsQuery = useQuery({
    queryKey: ["topups", "mine"],
    queryFn: () => apiGet<CoinTopup[]>("/topups/mine"),
    refetchInterval: 4000,
  });
  const topups = topupsQuery.data;
  const requestedTopup = params.get("topup");

  useEffect(() => {
    if (!requestedTopup) {
      setActive(null);
      return;
    }
    if (!topups) return;
    const latest = topups.find((topup) => topup.id === requestedTopup);
    setActive((current) => latest ?? (current?.id === requestedTopup ? current : null));
  }, [topups, requestedTopup]);

  const openTopup = (topup: CoinTopup) => {
    setActive(topup);
    setFile(null);
    setParams((previous) => {
      previous.set("topup", topup.id);
      return previous;
    }, { replace: true });
    topupPanel.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const closeTopup = () => {
    setActive(null);
    setFile(null);
    setParams((previous) => {
      previous.delete("topup");
      return previous;
    }, { replace: true });
  };

  const pricePer100 = settings?.coin_price_idr_per_100 ?? 110;
  const minCoins = settings?.min_topup_coins ?? 10000;
  const amount = coins > 0 ? Math.ceil(coins * pricePer100 / 10000) * 100 : 0;
  const availableMethods = MANUAL_METHODS.filter((m) =>
    (settings?.payment_accounts ?? []).some((a) => a.method === m),
  );
  const activeMethod = availableMethods.includes(method as typeof availableMethods[number]) ? method : availableMethods[0] ?? "";
  const accounts = (settings?.payment_accounts ?? []).filter((a) => a.method === active?.payment_method);

  const createTopup = useMutation({
    mutationFn: () => apiPost<CoinTopup>("/topups", { coins, payment_method: activeMethod }),
    onSuccess: (t) => {
      openTopup(t);
      qc.invalidateQueries({ queryKey: ["topups", "mine"] });
      toast.success(`Permintaan top-up ${t.code} dibuat!`);
    },
    onError: (e) =>
      toast.error(e instanceof ApiError ? (e.detail() ?? "Gagal membuat top-up") : "Gagal membuat top-up"),
  });

  const uploadProof = useMutation({
    mutationFn: () => apiUpload<CoinTopup>(`/topups/${active!.id}/proof`, file!),
    onSuccess: (t) => {
      setActive(t);
      setFile(null);
      qc.invalidateQueries({ queryKey: ["topups", "mine"] });
      toast.success("Bukti top-up terkirim! Admin akan segera memverifikasi.");
    },
    onError: (e) =>
      toast.error(e instanceof ApiError ? (e.detail() ?? "Gagal mengunggah bukti") : "Gagal mengunggah bukti"),
  });

  const wa = active && settings?.wa_number
    ? waLink(
        settings?.wa_number ?? "",
        topupWaText(active.code, active.coins, formatIDR(active.amount_idr), active.payment_method),
      )
    : null;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <h1 className="text-3xl">Saldo Coin</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Kumpulkan coin, bayar Robux lebih hemat — diskon {settings?.coin_discount_percent ?? 10}% untuk semua paket.
      </p>
      {settings?.store_open_now === false && !active && (
        <div className="mt-4 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm font-semibold text-amber-800 dark:text-amber-300" data-testid="topup-store-closed">
          Toko sedang tutup. Permintaan top-up baru tersedia saat toko buka kembali.
        </div>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        {/* BALANCE */}
        <Card className="border-amber-500/30 bg-gradient-to-br from-amber-500/15 via-pink-500/10 to-transparent lg:col-span-2">
          <CardHeader>
            <CardDescription className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              <Coins className="h-4 w-4" /> Saldo Coin Kamu
            </CardDescription>
            <CardTitle className="font-heading text-4xl text-amber-600 dark:text-amber-400" data-testid="coin-balance">
              {formatNumber(user?.coins ?? 0)}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <p>Harga top-up: 100 coin = {formatIDR(pricePer100)}. Bayar Robux pakai coin hemat {settings?.coin_discount_percent ?? 10}%.</p>
            <p>Perkiraan nilai saldo saat top-up: {formatIDR(Math.floor((user?.coins ?? 0) * pricePer100 / 100))}.</p>
            <Link to="/orders" data-testid="dashboard-my-orders-link" className={cn(buttonVariants({ variant: "outline", size: "sm" }), "w-full")}>
              <Package className="h-4 w-4" /> Lihat Pesanan Saya
            </Link>
          </CardContent>
        </Card>

        {/* TOP-UP FORM / ACTIVE TOPUP */}
        <Card ref={topupPanel} className="scroll-mt-20 border-pink-500/20 lg:col-span-3">
          {active ? (
            <CardContent className="space-y-4 p-6" data-testid="active-topup-panel">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="break-all font-heading text-lg font-extrabold">Top-Up #{active.code}</p>
                <TopupStatusBadge status={active.status} />
              </div>
              <p className="text-sm text-muted-foreground">
                {formatNumber(active.coins)} coin · {formatIDR(active.amount_idr)} ·{" "}
                {PAYMENT_LABELS[active.payment_method] ?? active.payment_method}
              </p>

              {active.status === "menunggu_pembayaran" && (
                <>
                  <div className="space-y-2" data-testid="topup-instructions">
                    <div className="flex items-center justify-between gap-2 rounded-xl bg-secondary p-3">
                      <div>
                        <p className="text-xs text-muted-foreground">Total yang harus dibayar</p>
                        <p className="font-bold text-primary">{formatIDR(active.amount_idr)}</p>
                      </div>
                      <CopyText value={String(active.amount_idr)} />
                    </div>
                    {active.payment_method === "qris" && settings?.qris_image_file_id && (
                      <img
                        src={fileUrl(settings.qris_image_file_id)}
                        alt="QRIS Dea Store"
                        className="mx-auto h-44 w-44 rounded-lg border border-pink-500/20 object-contain"
                      />
                    )}
                    {accounts.map((a) => (
                      <div key={a.method + a.number} className="flex items-center justify-between gap-2 rounded-xl border border-pink-500/20 bg-card px-3 py-2">
                        <div className="min-w-0">
                          <p className="break-words text-xs font-bold uppercase text-primary">{a.name}</p>
                          <p className="break-all font-mono text-sm font-semibold">{a.number}</p>
                        </div>
                        <CopyText value={a.number} />
                      </div>
                    ))}
                    {accounts.length === 0 && !(active.payment_method === "qris" && settings?.qris_image_file_id) && (
                      <p className="text-sm text-muted-foreground">Rekening pembayaran belum tersedia. Hubungi CS sebelum melakukan transfer.</p>
                    )}
                  </div>
                  <ProofUploader file={file} onFile={setFile} disabled={uploadProof.isPending} />
                  <Button data-testid="topup-upload-button" disabled={!file || uploadProof.isPending} className="w-full" onClick={() => uploadProof.mutate()}>
                    {uploadProof.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    Kirim Bukti Top-Up
                  </Button>
                </>
              )}

              {active.status === "menunggu_verifikasi" && (
                <p className="rounded-xl bg-sky-500/10 p-3 text-sm font-semibold text-sky-700 dark:text-sky-300">
                  Bukti diterima — menunggu verifikasi admin. Coin masuk otomatis setelah disetujui.
                </p>
              )}
              {active.status === "ditolak" && (
                <p className="rounded-xl bg-red-500/10 p-3 text-sm font-semibold text-red-700 dark:text-red-300" data-testid="topup-rejected-banner">
                  Ditolak: {active.reject_reason}
                </p>
              )}
              {active.status === "disetujui" && (
                <p className="rounded-xl bg-emerald-500/10 p-3 text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                  Disetujui! {formatNumber(active.coins)} coin sudah masuk ke saldo.
                </p>
              )}

              {wa && (
                <a
                  href={wa}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="topup-wa-button"
                  className={cn(buttonVariants({ variant: "outline" }), "w-full border-emerald-500 text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300")}
                >
                  <MessageCircle className="h-4 w-4" /> Konfirmasi Top-Up via WhatsApp
                </a>
              )}
              <Button variant="ghost" className="w-full" data-testid="topup-new-button" onClick={closeTopup} disabled={uploadProof.isPending}>
                Buat Top-Up Baru
              </Button>
            </CardContent>
          ) : (
            <CardContent className="space-y-4 p-6" data-testid="topup-form">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Wallet className="h-5 w-5 text-primary" /> Top-Up Coin
              </CardTitle>
              <div className="flex flex-wrap gap-2" data-testid="topup-presets">
                {PRESETS.map((p) => (
                  <button
                    key={p}
                    type="button"
                    data-testid={`topup-preset-${p}`}
                    onClick={() => setCoins(p)}
                    className={cn(
                      "rounded-full border px-4 py-1.5 text-sm font-bold transition-all hover:scale-105",
                      coins === p ? "border-amber-500 bg-amber-500/15 text-amber-700 dark:text-amber-300" : "border-pink-500/25",
                    )}
                  >
                    {formatNumber(p)}
                  </button>
                ))}
              </div>
              <div className="space-y-1">
                <label className="text-sm font-bold" htmlFor="topup-coins">Jumlah coin (minimal {formatNumber(minCoins)})</label>
                <Input
                  id="topup-coins"
                  data-testid="topup-coins-input"
                  type="number"
                  min={minCoins}
                  value={coins}
                  onChange={(e) => setCoins(Number(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-bold" htmlFor="topup-method">Metode pembayaran</label>
                <select
                  id="topup-method"
                  data-testid="topup-method-select"
                  value={activeMethod}
                  onChange={(e) => setMethod(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                >
                  {!availableMethods.length && <option value="">Belum ada metode pembayaran</option>}
                  {availableMethods.map((m) => (
                    <option key={m} value={m}>{PAYMENT_LABELS[m]}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-secondary p-3 text-sm">
                <span className="font-bold">Total bayar</span>
                <span className="font-heading text-xl font-extrabold text-primary" data-testid="topup-amount">
                  {formatIDR(amount)}
                </span>
              </div>
              <Button
                data-testid="topup-create-button"
                className="w-full"
                size="lg"
                disabled={coins < minCoins || !activeMethod || createTopup.isPending || settings?.store_open_now === false}
                onClick={() => createTopup.mutate()}
              >
                {createTopup.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Coins className="h-4 w-4" />}
                Buat Permintaan Top-Up
              </Button>
            </CardContent>
          )}
        </Card>
      </div>

      {/* HISTORY */}
      <Card className="mt-6 border-pink-500/20">
        <CardHeader>
          <CardTitle className="text-lg">Riwayat Top-Up Coin</CardTitle>
        </CardHeader>
        <CardContent>
          {topupsQuery.isPending && (
            <p role="status" className="py-6 text-center text-sm text-muted-foreground">Memuat riwayat top-up…</p>
          )}
          {topupsQuery.isError && (
            <div role="alert" className="space-y-3 rounded-xl border border-destructive/20 p-4 text-sm">
              <p>Riwayat top-up belum bisa dimuat. Coba lagi untuk melihat transaksi terbaru.</p>
              <Button variant="outline" onClick={() => void topupsQuery.refetch()} disabled={topupsQuery.isFetching}>Coba Lagi</Button>
            </div>
          )}
          {!topupsQuery.isError && topups?.length === 0 && (
            <p className="py-6 text-center text-sm text-muted-foreground">Belum ada top-up. Mulai dari {formatNumber(minCoins)} coin, ya!</p>
          )}
          <div className="space-y-3 sm:hidden" data-testid="topup-history-cards">
            {(topups ?? []).map((topup) => (
              <article key={topup.id} className="space-y-3 rounded-xl border border-pink-500/20 p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-mono font-bold text-primary">{topup.code}</p>
                  <TopupStatusBadge status={topup.status} />
                </div>
                <div className="text-sm">
                  <p className="font-semibold">{formatNumber(topup.coins)} coin · {formatIDR(topup.amount_idr)}</p>
                  <p className="text-muted-foreground">{PAYMENT_LABELS[topup.payment_method] ?? topup.payment_method}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{formatDateTime(topup.created_at)}</p>
                </div>
                <Button variant="outline" className="min-h-11 w-full" data-testid={`topup-open-mobile-${topup.code}`} onClick={() => openTopup(topup)} disabled={uploadProof.isPending}>
                  {topup.status === "menunggu_pembayaran" ? "Lanjut Bayar" : "Lihat Detail"}
                </Button>
              </article>
            ))}
          </div>
          <div className="hidden overflow-x-auto sm:block">
            <table className="w-full text-sm" data-testid="topup-history-table">
              <thead>
                <tr className="border-b border-pink-500/15 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="py-2 pr-4">Kode</th>
                  <th className="py-2 pr-4">Coin</th>
                  <th className="py-2 pr-4">Total</th>
                  <th className="py-2 pr-4">Metode</th>
                  <th className="py-2 pr-4">Status</th>
                  <th className="py-2">Tanggal</th>
                  <th className="py-2 pl-4">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {(topups ?? []).map((t) => (
                  <tr key={t.id} className="border-b border-pink-500/10">
                    <td className="py-2 pr-4 font-mono font-semibold">{t.code}</td>
                    <td className="py-2 pr-4">{formatNumber(t.coins)}</td>
                    <td className="py-2 pr-4">{formatIDR(t.amount_idr)}</td>
                    <td className="py-2 pr-4">{PAYMENT_LABELS[t.payment_method] ?? t.payment_method}</td>
                    <td className="py-2 pr-4"><TopupStatusBadge status={t.status} /></td>
                    <td className="py-2 text-xs text-muted-foreground">{formatDateTime(t.created_at)}</td>
                    <td className="py-2 pl-4">
                      <Button variant="outline" data-testid={`topup-open-${t.code}`} onClick={() => openTopup(t)} disabled={uploadProof.isPending}>
                        {t.status === "menunggu_pembayaran" ? "Lanjut Bayar" : "Lihat Detail"}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
