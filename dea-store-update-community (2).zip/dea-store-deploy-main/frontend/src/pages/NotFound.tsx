import { Link } from "react-router-dom";
import { buttonVariants } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-4 text-center">
      <p className="text-gradient-pink font-heading text-7xl font-extrabold" data-testid="not-found-code">404</p>
      <p className="text-muted-foreground">Halaman yang kamu cari tidak ditemukan.</p>
      <Link to="/" data-testid="not-found-home-link" className={buttonVariants()}>
        Kembali ke Beranda
      </Link>
    </div>
  );
}
