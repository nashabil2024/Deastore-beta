import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Check,
  ClipboardList,
  FileCheck2,
  Loader2,
  MessageCircle,
  PartyPopper,
  Search,
  Send,
  X,
} from "lucide-react";
import { ApiError, apiGet, apiUpload } from "@/lib/api";
import type { Order, StoreSettings } from "@/lib/types";
import {
  fileUrl,
  formatDateTime,
  formatIDR,
  formatNumber,
  orderWaText,
  PAYMENT_LABELS,
  waLink,
} from "@/lib/format";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import ProofUploader from "@/components/ProofUploader";
import CopyText from "@/components/CopyText";
import PaymentInstructions from "@/components/PaymentInstructions";
import { OrderStatusBadge } from "@/components/StatusBadge";
import { cn } from "@/lib/utils";

const STAGES = [
  { label: "Pesanan Dibuat", icon: ClipboardList },
  { label: "Bukti Diterima", icon: FileCheck2 },
  { label: "Diverifikasi & Diproses", icon: Loader2 },
  { label: "Robux Terkirim", icon: PartyPopper },
];

function stageOf(status: string): number {
  if (status === "menunggu_pembayaran") return 0;
  if (status === "menunggu_verifikasi") return 1;
  if (status === "diproses") return 2;
  if (status === "selesai") return 3;
  return 1; // ditolak — handled separately
}

export default function TrackPage() {
  const [params, setParams] = useSearchParams();
  const [code, setCode] = useState(params.get("code") ?? "");
  const submitted = params.get("code")?.trim().toUpperCase() || null;
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => {
    setCode(submitted ?? "");
    setFile(null);
  }, [submitted]);

  const { data: settings } = useQuery({ queryKey: ["settings"], queryFn: () => apiGet<StoreSettings>("/settings"), refetchInterval: 10000 });
  const q = useQuery({
    queryKey: ["order", submitted],
    queryFn: () => apiGet<Order>(`/orders/${encodeURIComponent(submitted!)}`),
    enabled: !!submitted,
    refetchInterval: 3000,
    retry: false,
  });
  const order = q.data;

  const uploadProof = useMutation({
    mutationFn: () => apiUpload<Order>(`/orders/${submitted}/proof`, file!),
    onSuccess: () => {
      toast.success("Bukti terkirim! Admin akan segera memverifikasi.");
      setFile(null);
      q.refetch();
    },
    onError: (e) =>
      toast.error(e instanceof ApiError ? (e.detail() ?? "Gagal mengunggah bukti") : "Gagal mengunggah bukti"),
  });

  const stage = order ? stageOf(order.status) : 0;
  const wa =
    order && settings?.wa_number &&
    waLink(
      settings?.wa_number ?? "",
      orderWaText(order.code, order.roblox_username, order.robux, formatIDR(order.total_idr), order.payment_method),
    );

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl">Cek Pesanan</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Masukkan kode pesanan (cth: DEA-8F3K2) untuk melihat status terkini.
      </p>

      <Card className="mt-6 border-pink-500/20">
        <CardContent className="p-4">
          <form className="flex gap-2" onSubmit={(event) => {
            event.preventDefault();
            if (code.trim().length < 5) return;
            const next = code.trim().toUpperCase();
            if (submitted === next) void q.refetch();
            else setParams({ code: next });
          }}>
          <Input
            data-testid="track-code-input"
            aria-label="Kode pesanan"
            autoCapitalize="characters"
            autoCorrect="off"
            placeholder="Kode pesanan, cth: DEA-8F3K2"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            maxLength={12}
            className="h-12 font-mono text-base"
          />
          <Button
            type="submit"
            data-testid="track-search-button"
            className="h-12"
            disabled={code.trim().length < 5}
          >
            <Search className="h-4 w-4" /> Cari
          </Button>
          </form>
        </CardContent>
      </Card>

      {submitted && q.isFetching && !order && (
        <p className="mt-6 flex items-center gap-2 text-sm text-muted-foreground" data-testid="track-loading">
          <Loader2 className="h-4 w-4 animate-spin text-primary" /> Mencari pesanan…
        </p>
      )}

      {submitted && q.isError && (
        <Card className="mt-6 border-red-300/60" data-testid="track-not-found">
          <CardContent className="space-y-3 p-6 text-center text-sm font-semibold text-destructive" role="alert">
            <p>{q.error instanceof ApiError && q.error.status === 404
              ? "Pesanan tidak ditemukan. Periksa kembali kode pesanannya, ya."
              : "Status pesanan belum dapat dimuat. Periksa koneksi lalu coba lagi."}</p>
            <Button variant="outline" onClick={() => q.refetch()} disabled={q.isFetching}>Coba Lagi</Button>
          </CardContent>
        </Card>
      )}

      {order && (
        <Card className="mt-6 border-pink-500/20" data-testid="track-result">
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <CardTitle className="flex flex-wrap items-center gap-2 text-xl">Pesanan #{order.code} <CopyText value={order.code} label="Salin kode pesanan" /></CardTitle>
              <OrderStatusBadge status={order.status} />
            </div>
            <CardDescription>
              {order.roblox_username} · {formatNumber(order.robux)} Robux ·{" "}
              {order.total_coins != null
                ? `${formatNumber(order.total_coins)} Coin`
                : formatIDR(order.total_idr)}{" "}
              · {PAYMENT_LABELS[order.payment_method] ?? order.payment_method}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-secondary p-3 text-sm">
              <span>Simpan tautan untuk melanjutkan pesanan ini.</span>
              <CopyText value={`${window.location.origin}/track?code=${encodeURIComponent(order.code)}`} label="Salin tautan pelacakan" />
            </div>
            {order.status === "ditolak" && (
              <div className="rounded-xl border border-red-300/60 bg-red-50 p-4 dark:border-red-500/40 dark:bg-red-500/10" data-testid="track-rejected-banner">
                <p className="flex items-center gap-2 font-bold text-red-700 dark:text-red-300">
                  <X className="h-4 w-4" /> Pesanan ditolak admin
                </p>
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">Alasan: {order.reject_reason}</p>
              </div>
            )}

            {/* TIMELINE */}
            <div className="grid gap-3 sm:grid-cols-4 sm:gap-2" data-testid="track-timeline">
              {STAGES.map((s, i) => {
                const done = i <= stage && order.status !== "ditolak";
                return (
                  <div key={s.label} aria-current={i === stage && order.status !== "ditolak" ? "step" : undefined} className="flex items-center gap-3 sm:flex-col sm:gap-1 sm:text-center">
                    <div
                      className={cn(
                        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 transition-colors",
                        done ? "border-primary bg-primary text-primary-foreground" : "border-pink-500/25 bg-card text-muted-foreground",
                      )}
                    >
                      {done ? <Check className="h-4 w-4" /> : <s.icon className="h-4 w-4" />}
                    </div>
                    <p className={cn("text-sm font-bold leading-tight sm:text-xs", done ? "text-primary" : "text-muted-foreground")}>
                      {order.payment_method === "coin" && i === 1 ? "Pembayaran Coin Diterima" : s.label}
                    </p>
                  </div>
                );
              })}
            </div>

            {order.proof_file_id && (
              <div className="flex items-center gap-3" data-testid="track-proof">
                <img
                  src={fileUrl(order.proof_file_id, order.code)}
                  alt={`Bukti pembayaran ${order.code}`}
                  className="h-24 w-24 rounded-xl border border-pink-500/20 object-cover"
                />
                <div className="text-sm">
                  <p className="font-bold">Bukti pembayaran</p>
                  <p className="text-xs text-muted-foreground">Diterima {formatDateTime(order.updated_at)}</p>
                </div>
              </div>
            )}

            {order.status === "menunggu_pembayaran" && (
              <div className="space-y-3" data-testid="track-upload-area">
                <PaymentInstructions settings={settings} method={order.payment_method} total={order.total_idr} />
                <p className="text-sm font-bold">Sudah bayar? Upload bukti pembayaranmu di sini:</p>
                <ProofUploader file={file} onFile={setFile} disabled={uploadProof.isPending} />
                <Button data-testid="track-upload-button" disabled={!file || uploadProof.isPending} className="w-full" onClick={() => uploadProof.mutate()}>
                  {uploadProof.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  Kirim Bukti Pembayaran
                </Button>
              </div>
            )}

            {order.payment_method !== "coin" && wa && (
              <a
                href={wa ?? "#"}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="track-wa-button"
                className={cn(buttonVariants({ variant: "outline" }), "w-full border-emerald-500 text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300 dark:hover:bg-emerald-500/10")}
              >
                <MessageCircle className="h-4 w-4" /> Konfirmasi via WhatsApp
              </a>
            )}
            {order.status === "selesai" && <Link to={`/order?robux=${order.robux}`} className={cn(buttonVariants(), "w-full")} data-testid="track-order-again">Top Up Lagi</Link>}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
