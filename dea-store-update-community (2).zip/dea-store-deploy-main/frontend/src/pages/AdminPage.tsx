import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  BarChart3,
  Bell,
  BellRing,
  CheckCircle2,
  ClipboardList,
  Coins,
  Loader2,
  Package as PackageIcon,
  Plus,
  QrCode,
  RefreshCw,
  Search,
  ScrollText,
  ShieldAlert,
  Trash2,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { ApiError, apiDelete, apiGet, apiPost, apiPut, apiUpload } from "@/lib/api";
import type {
  AdminLog,
  AdminStats,
  AdminUser,
  AiVerdict,
  CoinTopup,
  FakeFlag,
  Order,
  Package,
  PaymentAccount,
  StoreSettings,
  UserRole,
} from "@/lib/types";
import {
  BANK_METHODS,
  EWALLET_METHODS,
  fileUrl,
  formatDateTime,
  formatIDR,
  formatNumber,
  MANUAL_METHODS,
  PAYMENT_LABELS,
} from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { OrderStatusBadge, RiskBadge, TopupStatusBadge } from "@/components/StatusBadge";
import CommunityAdminTab from "@/pages/CommunityAdminTab";

const FILTER_LABELS: Record<string, string> = {
  all: "Semua",
  pending: "Perlu Tindakan",
  menunggu_pembayaran: "Menunggu Pembayaran",
  menunggu_verifikasi: "Menunggu Verifikasi",
  diproses: "Diproses",
  selesai: "Selesai",
  ditolak: "Ditolak",
  disetujui: "Disetujui",
};

const FILTERS_ORDER = ["all", "pending", "menunggu_verifikasi", "diproses", "selesai", "ditolak"];
const FILTERS_TOPUP = ["all", "pending", "menunggu_verifikasi", "disetujui", "ditolak"];

function errText(e: unknown): string {
  return e instanceof ApiError ? (e.detail() ?? "Terjadi kesalahan") : "Terjadi kesalahan";
}

function useAdminNotifications() {
  const supported = typeof window !== "undefined" && "Notification" in window;
  const [permission, setPermission] = useState<NotificationPermission>(supported ? Notification.permission : "denied");
  const seenOrders = useRef<Set<string> | null>(null);
  const seenTopups = useRef<Set<string> | null>(null);

  const orders = useQuery({
    queryKey: ["admin", "orders", "all"],
    queryFn: () => apiGet<Order[]>("/admin/orders"),
    refetchInterval: 5000,
    refetchIntervalInBackground: true,
  });
  const topups = useQuery({
    queryKey: ["admin", "topups", "all"],
    queryFn: () => apiGet<CoinTopup[]>("/admin/topups"),
    refetchInterval: 5000,
    refetchIntervalInBackground: true,
  });

  useEffect(() => {
    if (!orders.data) return;
    if (!seenOrders.current) {
      seenOrders.current = new Set(orders.data.map((o) => o.id));
      return;
    }
    const fresh = orders.data.filter((o) => !seenOrders.current!.has(o.id));
    for (const order of fresh) {
      const message = `${order.code} · ${order.roblox_username} · ${formatNumber(order.robux)} Robux`;
      toast.info(`Pesanan baru masuk`, { description: message });
      if ("Notification" in window && Notification.permission === "granted") {
        const notice = new Notification("Pesanan baru Dea Store", { body: message, tag: order.id });
        notice.onclick = () => window.focus();
      }
      seenOrders.current.add(order.id);
    }
  }, [orders.data]);

  useEffect(() => {
    if (!topups.data) return;
    if (!seenTopups.current) {
      seenTopups.current = new Set(topups.data.map((t) => t.id));
      return;
    }
    const fresh = topups.data.filter((t) => !seenTopups.current!.has(t.id));
    for (const topup of fresh) {
      const message = `${topup.code} · ${formatNumber(topup.coins)} coin · ${formatIDR(topup.amount_idr)}`;
      toast.info("Top-up coin baru masuk", { description: message });
      if ("Notification" in window && Notification.permission === "granted") {
        const notice = new Notification("Top-up baru Dea Store", { body: message, tag: topup.id });
        notice.onclick = () => window.focus();
      }
      seenTopups.current.add(topup.id);
    }
  }, [topups.data]);

  const enable = async () => {
    if (!supported) {
      toast.error("Browser ini tidak mendukung notifikasi desktop.");
      return;
    }
    const next = await Notification.requestPermission();
    setPermission(next);
    if (next === "granted") toast.success("Notifikasi pesanan di perangkat ini aktif.");
  };

  return { permission, enable };
}

/* ============ DASHBOARD ============ */

function DashboardTab() {
  const stats = useQuery({
    queryKey: ["admin", "stats"],
    queryFn: () => apiGet<AdminStats>("/admin/stats"),
    refetchInterval: 5000,
  });
  const logs = useQuery({ queryKey: ["admin", "logs"], queryFn: () => apiGet<AdminLog[]>("/admin/logs"), refetchInterval: 10000 });

  const cards = [
    { label: "Pesanan Perlu Tindakan", value: stats.data?.orders_pending ?? 0, icon: ClipboardList, testid: "stat-orders-pending" },
    { label: "Pesanan Hari Ini", value: stats.data?.orders_today ?? 0, icon: BarChart3, testid: "stat-orders-today" },
    { label: "Pendapatan Disetujui", value: formatIDR(stats.data?.revenue_idr ?? 0), icon: Coins, testid: "stat-revenue" },
    { label: "Robux Terjual", value: formatNumber(stats.data?.robux_sold ?? 0), icon: PackageIcon, testid: "stat-robux-sold" },
    { label: "Top-Up Coin Pending", value: stats.data?.topups_pending ?? 0, icon: Wallet, testid: "stat-topups-pending" },
    { label: "Total Pengguna", value: formatNumber(stats.data?.users_count ?? 0), icon: Users, testid: "stat-users" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        {cards.map((c) => (
          <Card key={c.label} className="border-pink-500/15">
            <CardContent className="flex flex-col items-start gap-2 p-3 sm:flex-row sm:items-center sm:gap-3 sm:p-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                <c.icon className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-muted-foreground">{c.label}</p>
                <p className="break-words font-heading text-lg font-extrabold sm:text-xl" data-testid={c.testid}>{c.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-pink-500/15">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ScrollText className="h-4 w-4 text-primary" /> Log Aktivitas Admin
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm" data-testid="admin-logs-table">
              <thead>
                <tr className="border-b border-pink-500/15 text-left text-xs uppercase text-muted-foreground">
                  <th className="py-2 pr-4">Waktu</th>
                  <th className="py-2 pr-4">Admin</th>
                  <th className="py-2 pr-4">Aksi</th>
                  <th className="py-2 pr-4">Target</th>
                  <th className="py-2">Detail</th>
                </tr>
              </thead>
              <tbody>
                {(logs.data ?? []).map((l) => (
                  <tr key={l.id} className="border-b border-pink-500/10">
                    <td className="py-2 pr-4 text-xs text-muted-foreground">{formatDateTime(l.created_at)}</td>
                    <td className="py-2 pr-4 font-semibold">{l.admin_username}</td>
                    <td className="py-2 pr-4"><Badge variant="secondary">{l.action}</Badge></td>
                    <td className="py-2 pr-4 font-mono text-xs">{l.target}</td>
                    <td className="py-2 text-xs text-muted-foreground">{l.detail}</td>
                  </tr>
                ))}
                {logs.data && logs.data.length === 0 && (
                  <tr><td colSpan={5} className="py-6 text-center text-muted-foreground">Belum ada aktivitas.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ============ ORDERS ============ */

function AiVerdictPanel({ flags, verdict }: { flags: FakeFlag[]; verdict: AiVerdict | null }) {
  const duplicate = flags.length > 0;
  return (
    <div className="space-y-3 rounded-xl border border-pink-500/20 bg-card p-4" data-testid="ai-verdict-panel">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-sm font-extrabold">
          <ShieldAlert className="h-4 w-4 text-primary" /> Deteksi Pembayaran Palsu
        </p>
        <RiskBadge risk={verdict?.risk ?? null} duplicate={duplicate} />
      </div>

      {duplicate ? (
        <div className="rounded-lg bg-red-500/10 p-3 text-sm font-semibold text-red-700 dark:text-red-300" data-testid="proof-duplicate-flags">
          <p className="flex items-center gap-1.5">
            <X className="h-4 w-4" /> Bukti ini identik dengan upload sebelumnya:
          </p>
          <ul className="mt-1 list-inside list-disc text-xs">
            {flags.map((f, i) => (
              <li key={i}>
                {f.kind === "exact" ? "Gambar sama persis" : "Gambar mirip"} — dipakai di{" "}
                {f.ref_code} ({f.ref_type === "topup" ? "top-up coin" : "pesanan"})
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {!verdict || verdict.ai_status === "pending" ? (
        <p className="flex items-center gap-2 text-xs font-semibold text-muted-foreground" data-testid="ai-verdict-pending">
          <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" /> AI sedang menganalisis bukti…
        </p>
      ) : verdict.ai_status === "unavailable" ? (
        <p className="text-xs font-semibold text-amber-700 dark:text-amber-400" data-testid="ai-verdict-unavailable">
          Analisis AI tidak tersedia — verifikasi manual diperlukan.
        </p>
      ) : (
        <div className="space-y-1 text-sm" data-testid="ai-verdict-done">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Terlihat seperti bukti asli?</span>
            <span className="font-bold">{verdict.looks_like_payment_proof ? "Ya" : "Tidak / Meragukan"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Nominal terdeteksi</span>
            <span className="font-bold">{verdict.detected_amount != null ? formatIDR(verdict.detected_amount) : "—"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Metode terdeteksi</span>
            <span className="font-bold">{verdict.detected_method ?? "—"}</span>
          </div>
          {verdict.edited_signs && (
            <div className="flex justify-between gap-4">
              <span className="shrink-0 text-muted-foreground">Tanda editan</span>
              <span className="text-right font-bold text-red-600 dark:text-red-400">{verdict.edited_signs}</span>
            </div>
          )}
          <p className="rounded-lg bg-secondary p-2 text-xs text-muted-foreground">{verdict.notes}</p>
        </div>
      )}
    </div>
  );
}

function OrderDialog({ orderId, onClose }: { orderId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [rejecting, setRejecting] = useState(false);
  const [reason, setReason] = useState("");

  const q = useQuery({
    queryKey: ["admin", "order", orderId],
    queryFn: () => apiGet<Order>(`/admin/orders/${orderId}`),
    enabled: !!orderId,
    refetchInterval: 3000,
  });
  const o = q.data;

  const act = useMutation({
    mutationFn: (p: { path: string; body?: unknown }) => apiPost<Order>(p.path, p.body ?? null),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin"] });
      setRejecting(false);
      setReason("");
      toast.success("Aksi berhasil dicatat");
    },
    onError: (e) => toast.error(errText(e)),
  });

  return (
    <Dialog open={!!orderId} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-3xl" data-testid="admin-order-dialog">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2">
            Pesanan #{o?.code ?? orderId} {o && <OrderStatusBadge status={o.status} />}
          </DialogTitle>
          <DialogDescription>
            {o && (
              <>
                {o.roblox_username}
                {o.roblox_profile ? ` (ID ${o.roblox_profile.user_id ?? "?"})` : " (belum terverifikasi)"} ·{" "}
                {formatNumber(o.robux)} Robux ·{" "}
                {o.total_coins != null ? `${formatNumber(o.total_coins)} coin` : formatIDR(o.total_idr)} ·{" "}
                {PAYMENT_LABELS[o.payment_method] ?? o.payment_method} · {formatDateTime(o.created_at)}
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        {o && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              {o.proof_file_id ? (
                <a href={fileUrl(o.proof_file_id)} target="_blank" rel="noopener noreferrer">
                  <img
                    src={fileUrl(o.proof_file_id)}
                    alt={`Bukti pembayaran ${o.code}`}
                    className="max-h-72 w-full rounded-xl border border-pink-500/20 object-contain"
                    data-testid="admin-proof-image"
                  />
                  <p className="mt-1 text-center text-xs text-primary hover:underline">Buka gambar penuh ↗</p>
                </a>
              ) : (
                <div className="flex h-48 items-center justify-center rounded-xl border border-dashed border-pink-500/30 text-sm text-muted-foreground">
                  Belum ada bukti pembayaran
                </div>
              )}
              {o.note && <p className="rounded-lg bg-secondary p-2 text-xs">Catatan pembeli: {o.note}</p>}
            </div>

            <div className="space-y-3">
              <AiVerdictPanel flags={o.proof_flags} verdict={o.ai_verdict} />

              <div className="flex flex-wrap gap-2">
                {o.status === "menunggu_verifikasi" && (
                  <Button
                    size="sm"
                    data-testid="admin-approve-order-btn"
                    disabled={act.isPending}
                    onClick={() => act.mutate({ path: `/admin/orders/${o.id}/approve` })}
                  >
                    <CheckCircle2 className="h-4 w-4" /> Setujui &amp; Proses
                  </Button>
                )}
                {o.status === "diproses" && (
                  <Button
                    size="sm"
                    data-testid="admin-complete-order-btn"
                    disabled={act.isPending}
                    onClick={() => act.mutate({ path: `/admin/orders/${o.id}/complete` })}
                  >
                    <CheckCircle2 className="h-4 w-4" /> Tandai Selesai
                  </Button>
                )}
                {(o.status === "menunggu_pembayaran" || o.status === "ditolak") && (
                  <Button
                    size="sm"
                    variant="outline"
                    data-testid="admin-delete-order-btn"
                    disabled={act.isPending}
                    onClick={() => {
                      if (!window.confirm(`Hapus pesanan ${o.code}? Pesanan tidak dapat dikembalikan.`)) return;
                      apiDelete<{ ok: boolean }>(`/admin/orders/${o.id}`)
                        .then(() => {
                          qc.invalidateQueries({ queryKey: ["admin"] });
                          toast.success("Pesanan dibatalkan sudah dihapus");
                          onClose();
                        })
                        .catch((error: unknown) => toast.error(errText(error)));
                    }}
                    className="border-red-300 text-red-700 hover:bg-red-50 dark:border-red-500/40 dark:text-red-300"
                  >
                    <Trash2 className="h-4 w-4" /> Hapus Pesanan
                  </Button>
                )}
                {(o.status === "menunggu_verifikasi" || o.status === "diproses") && (
                  <Button
                    size="sm"
                    variant="destructive"
                    data-testid="admin-reject-order-btn"
                    disabled={act.isPending}
                    onClick={() => setRejecting((r) => !r)}
                  >
                    <X className="h-4 w-4" /> Tolak
                  </Button>
                )}
                {o.proof_file_id && (
                  <Button
                    size="sm"
                    variant="outline"
                    data-testid="admin-rescan-order-btn"
                    disabled={act.isPending}
                    onClick={() => act.mutate({ path: `/admin/orders/${o.id}/rescan` })}
                  >
                    <RefreshCw className="h-4 w-4" /> Scan Ulang AI
                  </Button>
                )}
              </div>

              {rejecting && (
                <div className="space-y-2 rounded-xl border border-red-300/60 p-3" data-testid="admin-reject-form">
                  <Label htmlFor="reject-reason">Alasan penolakan (wajib)</Label>
                  <Textarea
                    id="reject-reason"
                    data-testid="admin-reject-reason-input"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="cth: Bukti pembayaran tidak sesuai / gambar palsu"
                    rows={2}
                    maxLength={300}
                  />
                  <Button
                    size="sm"
                    variant="destructive"
                    data-testid="admin-reject-confirm-btn"
                    disabled={reason.trim().length < 3 || act.isPending}
                    onClick={() => act.mutate({ path: `/admin/orders/${o.id}/reject`, body: { reason: reason.trim() } })}
                  >
                    Kirim Penolakan
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function OrdersTab() {
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const q = useQuery({
    queryKey: ["admin", "orders", filter],
    queryFn: () => apiGet<Order[]>(`/admin/orders${filter === "all" ? "" : `?status=${filter}`}`),
    refetchInterval: 5000,
    refetchIntervalInBackground: true,
  });
  const needle = search.trim().toLocaleLowerCase("id-ID");
  const orders = (q.data ?? []).filter((order) =>
    `${order.code} ${order.roblox_username}`.toLocaleLowerCase("id-ID").includes(needle),
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="relative min-w-0 flex-1 sm:max-w-sm">
          <Label htmlFor="admin-orders-search" className="mb-1.5 block text-xs">Cari pesanan</Label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input id="admin-orders-search" data-testid="admin-orders-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Kode pesanan atau username Roblox" className="h-11 pl-9" />
          </div>
        </div>
        <div className="flex min-w-0 flex-wrap items-center gap-2">
        <Select value={filter} onValueChange={(v: string) => setFilter(v)}>
          <SelectTrigger className="h-11 w-full min-w-0 sm:w-56" data-testid="admin-orders-filter">
            <SelectValue>{(v) => FILTER_LABELS[String(v)]}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {FILTERS_ORDER.map((s) => (
              <SelectItem key={s} value={s} data-testid={`admin-orders-filter-${s}`}>
                {FILTER_LABELS[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex w-full items-center justify-between gap-2 sm:w-auto">
          <Badge variant="outline">{orders.length} pesanan{needle ? ` dari ${q.data?.length ?? 0}` : ""}</Badge>
          <Button size="icon-sm" className="h-11 w-11" variant="outline" aria-label="Muat ulang pesanan" onClick={() => q.refetch()} disabled={q.isFetching}>
            <RefreshCw className={q.isFetching ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
          </Button>
        </div>
        </div>
      </div>

      {q.isPending && <p role="status" className="flex items-center gap-2 rounded-xl border border-border p-4 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Memuat pesanan…</p>}
      {q.isError && <div role="alert" className="rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">Pesanan belum dapat dimuat. Gunakan tombol muat ulang untuk mencoba lagi.</div>}
      {!q.isPending && !q.isError && orders.length === 0 && <p className="rounded-xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">{needle ? "Tidak ada pesanan yang cocok. Coba kode atau username lain, atau ubah filter status." : "Tidak ada pesanan pada filter ini."}</p>}

      <div className="space-y-3 sm:hidden" data-testid="admin-orders-mobile">
        {orders.map((o) => (
          <article key={o.id} className="min-w-0 space-y-3 rounded-xl border border-pink-500/20 bg-card p-4">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="min-w-0"><p className="break-all font-mono text-sm font-bold">{o.code}</p><p className="mt-1 break-words text-sm font-semibold">{o.roblox_username}</p></div>
              <OrderStatusBadge status={o.status} />
            </div>
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div><dt className="text-xs text-muted-foreground">Jumlah</dt><dd className="mt-1 font-semibold">{formatNumber(o.robux)} Robux</dd></div>
              <div><dt className="text-xs text-muted-foreground">Total</dt><dd className="mt-1 break-words font-semibold">{o.total_coins != null ? `${formatNumber(o.total_coins)} coin` : formatIDR(o.total_idr)}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Metode</dt><dd className="mt-1">{PAYMENT_LABELS[o.payment_method] ?? o.payment_method}</dd></div>
              <div><dt className="mb-1 text-xs text-muted-foreground">Risiko bukti</dt><dd><RiskBadge risk={o.ai_verdict?.risk ?? null} duplicate={o.proof_flags.length > 0} /></dd></div>
            </dl>
            <Button variant="outline" className="h-11 w-full" data-testid={`admin-order-mobile-detail-${o.code}`} onClick={() => setSelectedId(o.id)}>Lihat Detail Pesanan</Button>
          </article>
        ))}
      </div>
      <div className="hidden overflow-x-auto rounded-xl border border-pink-500/15 sm:block">
        <table className="w-full text-sm" data-testid="admin-orders-table">
          <thead>
            <tr className="border-b border-pink-500/15 bg-secondary/50 text-left text-xs uppercase text-muted-foreground">
              <th className="p-3 pr-4">Kode</th>
              <th className="p-3 pr-4">Roblox</th>
              <th className="p-3 pr-4">Robux</th>
              <th className="p-3 pr-4">Total</th>
              <th className="p-3 pr-4">Metode</th>
              <th className="p-3 pr-4">Status</th>
              <th className="p-3 pr-4">Risiko</th>
              <th className="p-3">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} className="border-b border-pink-500/10 hover:bg-secondary/40">
                <td className="p-3 pr-4 font-mono font-bold">{o.code}</td>
                <td className="p-3 pr-4 font-semibold">{o.roblox_username}</td>
                <td className="p-3 pr-4">{formatNumber(o.robux)}</td>
                <td className="p-3 pr-4">{o.total_coins != null ? `${formatNumber(o.total_coins)} coin` : formatIDR(o.total_idr)}</td>
                <td className="p-3 pr-4">{PAYMENT_LABELS[o.payment_method] ?? o.payment_method}</td>
                <td className="p-3 pr-4"><OrderStatusBadge status={o.status} /></td>
                <td className="p-3 pr-4">
                  <RiskBadge risk={o.ai_verdict?.risk ?? null} duplicate={o.proof_flags.length > 0} />
                </td>
                <td className="p-3">
                  <Button size="xs" variant="outline" data-testid={`admin-order-detail-${o.code}`} onClick={() => setSelectedId(o.id)}>
                    Detail
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedId && <OrderDialog orderId={selectedId} onClose={() => setSelectedId(null)} />}
    </div>
  );
}

/* ============ TOP-UPS ============ */

function TopupDialog({ topupId, onClose }: { topupId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [rejecting, setRejecting] = useState(false);
  const [reason, setReason] = useState("");

  // Topup detail comes from the admin list (refetched on every admin mutation).
  const list = useQuery({
    queryKey: ["admin", "topups", "all"],
    queryFn: () => apiGet<CoinTopup[]>("/admin/topups"),
    refetchInterval: 5000,
  });
  const t = (list.data ?? []).find((x) => x.id === topupId) ?? null;

  const act = useMutation({
    mutationFn: (p: { path: string; body?: unknown }) => apiPost<CoinTopup>(p.path, p.body ?? null),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin"] });
      setRejecting(false);
      setReason("");
      toast.success("Aksi berhasil dicatat");
    },
    onError: (e) => toast.error(errText(e)),
  });

  return (
    <Dialog open={!!topupId} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-3xl" data-testid="admin-topup-dialog">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2">
            Top-Up #{t?.code ?? topupId} {t && <TopupStatusBadge status={t.status} />}
          </DialogTitle>
          <DialogDescription>
            {t && `${t.coins} coin · ${formatIDR(t.amount_idr)} · ${PAYMENT_LABELS[t.payment_method] ?? t.payment_method}`}
          </DialogDescription>
        </DialogHeader>

        {t && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              {t.proof_file_id ? (
                <a href={fileUrl(t.proof_file_id)} target="_blank" rel="noopener noreferrer">
                  <img
                    src={fileUrl(t.proof_file_id)}
                    alt={`Bukti top-up ${t.code}`}
                    className="max-h-72 w-full rounded-xl border border-pink-500/20 object-contain"
                    data-testid="admin-topup-proof-image"
                  />
                  <p className="mt-1 text-center text-xs text-primary hover:underline">Buka gambar penuh ↗</p>
                </a>
              ) : (
                <div className="flex h-48 items-center justify-center rounded-xl border border-dashed border-pink-500/30 text-sm text-muted-foreground">
                  Belum ada bukti pembayaran
                </div>
              )}
            </div>
            <div className="space-y-3">
              <AiVerdictPanel flags={t.proof_flags} verdict={t.ai_verdict} />

              <div className="flex flex-wrap gap-2">
                {t.status === "menunggu_verifikasi" && (
                  <Button
                    size="sm"
                    data-testid="admin-approve-topup-btn"
                    disabled={act.isPending}
                    onClick={() => act.mutate({ path: `/admin/topups/${t.id}/approve` })}
                  >
                    <Coins className="h-4 w-4" /> Setujui (+{formatNumber(t.coins)} coin)
                  </Button>
                )}
                {t.status === "menunggu_verifikasi" && (
                  <Button size="sm" variant="destructive" data-testid="admin-reject-topup-btn" onClick={() => setRejecting((r) => !r)}>
                    <X className="h-4 w-4" /> Tolak
                  </Button>
                )}
                {t.proof_file_id && (
                  <Button
                    size="sm"
                    variant="outline"
                    data-testid="admin-rescan-topup-btn"
                    disabled={act.isPending}
                    onClick={() => act.mutate({ path: `/admin/topups/${t.id}/rescan` })}
                  >
                    <RefreshCw className="h-4 w-4" /> Scan Ulang AI
                  </Button>
                )}
              </div>

              {rejecting && (
                <div className="space-y-2 rounded-xl border border-red-300/60 p-3">
                  <Label htmlFor="topup-reject-reason">Alasan penolakan (wajib)</Label>
                  <Textarea
                    id="topup-reject-reason"
                    data-testid="admin-topup-reject-reason-input"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    rows={2}
                    maxLength={300}
                    placeholder="cth: Nominal transfer tidak sesuai"
                  />
                  <Button
                    size="sm"
                    variant="destructive"
                    data-testid="admin-topup-reject-confirm-btn"
                    disabled={reason.trim().length < 3 || act.isPending}
                    onClick={() => act.mutate({ path: `/admin/topups/${t.id}/reject`, body: { reason: reason.trim() } })}
                  >
                    Kirim Penolakan
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function TopupsTab() {
  const [filter, setFilter] = useState("pending");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const q = useQuery({
    queryKey: ["admin", "topups", filter],
    queryFn: () => apiGet<CoinTopup[]>(`/admin/topups${filter === "all" ? "" : `?status=${filter}`}`),
    refetchInterval: 5000,
  });
  const needle = search.trim().toLocaleLowerCase("id-ID");
  const topups = (q.data ?? []).filter((topup) => topup.code.toLocaleLowerCase("id-ID").includes(needle));

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0 flex-1 sm:max-w-sm">
          <Label htmlFor="admin-topups-search" className="mb-1.5 block text-xs">Cari top-up</Label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input id="admin-topups-search" data-testid="admin-topups-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Kode top-up, cth: TUP-8F3K2" className="h-11 pl-9" />
          </div>
        </div>
        <div className="flex min-w-0 flex-wrap items-center gap-2">
        <Select value={filter} onValueChange={(v: string) => setFilter(v)}>
          <SelectTrigger className="h-11 w-full min-w-0 sm:w-56" data-testid="admin-topups-filter">
            <SelectValue>{(v) => FILTER_LABELS[String(v)]}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {FILTERS_TOPUP.map((s) => (
              <SelectItem key={s} value={s} data-testid={`admin-topups-filter-${s}`}>
                {FILTER_LABELS[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex w-full items-center justify-between gap-2 sm:w-auto">
          <Badge variant="outline">{topups.length} permintaan{needle ? ` dari ${q.data?.length ?? 0}` : ""}</Badge>
          <Button size="icon-sm" className="h-11 w-11" variant="outline" aria-label="Muat ulang top-up" onClick={() => q.refetch()} disabled={q.isFetching}>
            <RefreshCw className={q.isFetching ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
          </Button>
        </div>
        </div>
      </div>

      {q.isPending && <p role="status" className="flex items-center gap-2 rounded-xl border border-border p-4 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Memuat top-up…</p>}
      {q.isError && <div role="alert" className="rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">Top-up belum dapat dimuat. Gunakan tombol muat ulang untuk mencoba lagi.</div>}
      {!q.isPending && !q.isError && topups.length === 0 && <p className="rounded-xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">{needle ? "Tidak ada top-up yang cocok. Coba kode lain, atau ubah filter status." : "Tidak ada permintaan top-up pada filter ini."}</p>}

      <div className="space-y-3 sm:hidden" data-testid="admin-topups-mobile">
        {topups.map((t) => (
          <article key={t.id} className="min-w-0 space-y-3 rounded-xl border border-pink-500/20 bg-card p-4">
            <div className="flex flex-wrap items-start justify-between gap-2"><p className="break-all font-mono text-sm font-bold">{t.code}</p><TopupStatusBadge status={t.status} /></div>
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div><dt className="text-xs text-muted-foreground">Jumlah coin</dt><dd className="mt-1 font-semibold">{formatNumber(t.coins)} coin</dd></div>
              <div><dt className="text-xs text-muted-foreground">Total</dt><dd className="mt-1 break-words font-semibold">{formatIDR(t.amount_idr)}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Metode</dt><dd className="mt-1">{PAYMENT_LABELS[t.payment_method] ?? t.payment_method}</dd></div>
              <div><dt className="mb-1 text-xs text-muted-foreground">Risiko bukti</dt><dd><RiskBadge risk={t.ai_verdict?.risk ?? null} duplicate={t.proof_flags.length > 0} /></dd></div>
            </dl>
            <Button variant="outline" className="h-11 w-full" data-testid={`admin-topup-mobile-detail-${t.code}`} onClick={() => setSelectedId(t.id)}>Lihat Detail Top-Up</Button>
          </article>
        ))}
      </div>
      <div className="hidden overflow-x-auto rounded-xl border border-pink-500/15 sm:block">
        <table className="w-full text-sm" data-testid="admin-topups-table">
          <thead>
            <tr className="border-b border-pink-500/15 bg-secondary/50 text-left text-xs uppercase text-muted-foreground">
              <th className="p-3 pr-4">Kode</th>
              <th className="p-3 pr-4">Coin</th>
              <th className="p-3 pr-4">Total</th>
              <th className="p-3 pr-4">Metode</th>
              <th className="p-3 pr-4">Status</th>
              <th className="p-3 pr-4">Risiko</th>
              <th className="p-3">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {topups.map((t) => (
              <tr key={t.id} className="border-b border-pink-500/10 hover:bg-secondary/40">
                <td className="p-3 pr-4 font-mono font-bold">{t.code}</td>
                <td className="p-3 pr-4">{formatNumber(t.coins)}</td>
                <td className="p-3 pr-4">{formatIDR(t.amount_idr)}</td>
                <td className="p-3 pr-4">{PAYMENT_LABELS[t.payment_method] ?? t.payment_method}</td>
                <td className="p-3 pr-4"><TopupStatusBadge status={t.status} /></td>
                <td className="p-3 pr-4">
                  <RiskBadge risk={t.ai_verdict?.risk ?? null} duplicate={t.proof_flags.length > 0} />
                </td>
                <td className="p-3">
                  <Button size="xs" variant="outline" data-testid={`admin-topup-detail-${t.code}`} onClick={() => setSelectedId(t.id)}>
                    Detail
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedId && <TopupDialog topupId={selectedId} onClose={() => setSelectedId(null)} />}
    </div>
  );
}

/* ============ PACKAGES ============ */

function PackageForm({ initial, onDone }: { initial: Package | "new"; onDone: () => void }) {
  const qc = useQueryClient();
  const isNew = initial === "new";
  const [robux, setRobux] = useState(isNew ? "" : String(initial.robux));
  const [price, setPrice] = useState(isNew ? "" : String(initial.price_idr));
  const [tag, setTag] = useState(isNew ? "" : initial.tag ?? "");
  const [sort, setSort] = useState(isNew ? "99" : String(initial.sort));
  const [active, setActive] = useState(isNew ? true : initial.active);

  const save = useMutation({
    mutationFn: () =>
      isNew
        ? apiPost<Package>("/admin/packages", {
            robux: Number(robux), price_idr: Number(price), tag: tag.trim() || null,
            active, sort: Number(sort) || 99,
          })
        : apiPut<Package>(`/admin/packages/${initial.id}`, {
            robux: Number(robux), price_idr: Number(price), tag: tag.trim() || null,
            active, sort: Number(sort) || 99,
          }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin"] });
      qc.invalidateQueries({ queryKey: ["packages"] });
      toast.success(isNew ? "Paket ditambahkan" : "Paket diperbarui");
      onDone();
    },
    onError: (e) => toast.error(errText(e)),
  });

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label htmlFor="pkg-robux">Jumlah Robux</Label>
          <Input id="pkg-robux" data-testid="pkg-robux-input" type="number" min={1} value={robux} onChange={(e) => setRobux(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="pkg-price">Harga (Rp)</Label>
          <Input id="pkg-price" data-testid="pkg-price-input" type="number" min={1} value={price} onChange={(e) => setPrice(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="pkg-tag">Label (opsional)</Label>
          <Input id="pkg-tag" data-testid="pkg-tag-input" value={tag} onChange={(e) => setTag(e.target.value)} placeholder="cth: Best Seller" maxLength={20} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="pkg-sort">Urutan</Label>
          <Input id="pkg-sort" data-testid="pkg-sort-input" type="number" value={sort} onChange={(e) => setSort(e.target.value)} />
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Checkbox id="pkg-active" data-testid="pkg-active-checkbox" checked={active} onCheckedChange={(v) => setActive(v === true)} />
        <Label htmlFor="pkg-active">Paket aktif (tampil di katalog)</Label>
      </div>
      <DialogFooter>
        <Button variant="outline" data-testid="pkg-cancel-button" onClick={onDone}>Batal</Button>
        <Button
          data-testid="pkg-save-button"
          disabled={!Number(robux) || !Number(price) || save.isPending}
          onClick={() => save.mutate()}
        >
          {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Simpan
        </Button>
      </DialogFooter>
    </div>
  );
}

function PackagesTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin", "packages"], queryFn: () => apiGet<Package[]>("/admin/packages"), refetchInterval: 10000 });
  const [editing, setEditing] = useState<Package | "new" | null>(null);

  const del = useMutation({
    mutationFn: (id: string) => apiDelete(`/admin/packages/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin"] });
      qc.invalidateQueries({ queryKey: ["packages"] });
      toast.success("Paket dihapus");
    },
    onError: (e) => toast.error(errText(e)),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Harga standar: Rp150 per Robux. Ubah harga &amp; kelola paket di sini.</p>
        <Button size="sm" data-testid="admin-package-add-btn" onClick={() => setEditing("new")}>
          <Plus className="h-4 w-4" /> Tambah Paket
        </Button>
      </div>
      <div className="overflow-x-auto rounded-xl border border-pink-500/15">
        <table className="w-full text-sm" data-testid="admin-packages-table">
          <thead>
            <tr className="border-b border-pink-500/15 bg-secondary/50 text-left text-xs uppercase text-muted-foreground">
              <th className="p-3 pr-4">Robux</th>
              <th className="p-3 pr-4">Harga</th>
              <th className="p-3 pr-4">Rp/Robux</th>
              <th className="p-3 pr-4">Label</th>
              <th className="p-3 pr-4">Aktif</th>
              <th className="p-3">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {(q.data ?? []).map((p) => (
              <tr key={p.id} className="border-b border-pink-500/10 hover:bg-secondary/40">
                <td className="p-3 pr-4 font-bold">{formatNumber(p.robux)}</td>
                <td className="p-3 pr-4">{formatIDR(p.price_idr)}</td>
                <td className="p-3 pr-4">{formatIDR(Math.round(p.price_idr / p.robux))}</td>
                <td className="p-3 pr-4">{p.tag ? <Badge>{p.tag}</Badge> : "—"}</td>
                <td className="p-3 pr-4">{p.active ? <Badge className="bg-emerald-600">Aktif</Badge> : <Badge variant="outline">Nonaktif</Badge>}</td>
                <td className="p-3">
                  <div className="flex gap-1">
                    <Button size="xs" variant="outline" data-testid={`admin-package-edit-${p.robux}`} onClick={() => setEditing(p)}>Edit</Button>
                    <Button size="xs" variant="ghost" data-testid={`admin-package-delete-${p.robux}`} onClick={() => del.mutate(p.id)}>
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="sm:max-w-md" data-testid="admin-package-dialog">
          <DialogHeader>
            <DialogTitle>{editing === "new" ? "Tambah Paket" : editing ? `Edit Paket ${editing.robux} Robux` : ""}</DialogTitle>
            <DialogDescription>Harga tampil langsung di katalog pembeli.</DialogDescription>
          </DialogHeader>
          {editing && <PackageForm initial={editing} onDone={() => setEditing(null)} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ============ USERS ============ */

function AdjustDialog({ target, onClose }: { target: AdminUser; onClose: () => void }) {
  const qc = useQueryClient();
  const [delta, setDelta] = useState("");
  const [note, setNote] = useState("");

  const m = useMutation({
    mutationFn: () =>
      apiPost<AdminUser>(`/admin/users/${target.id}/adjust-coins`, { delta: Number(delta), note: note.trim() || null }),
    onSuccess: (updatedUser) => {
      qc.setQueryData<AdminUser[]>(["admin", "users"], (users) =>
        users?.map((user) => (user.id === updatedUser.id ? updatedUser : user)),
      );
      qc.invalidateQueries({ queryKey: ["admin"] });
      toast.success("Saldo coin diperbarui");
      onClose();
    },
    onError: (e) => toast.error(errText(e)),
  });

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
        Saldo sekarang: <strong className="text-foreground">{formatNumber(target.coins)} coin</strong>. Gunakan
        angka negatif untuk mengurangi.
      </p>
      <div className="space-y-1">
        <Label htmlFor="adjust-delta">Perubahan (cth: 5000 atau -2000)</Label>
        <Input id="adjust-delta" data-testid="adjust-delta-input" type="number" value={delta} onChange={(e) => setDelta(e.target.value)} />
      </div>
      <div className="space-y-1">
        <Label htmlFor="adjust-note">Catatan (opsional)</Label>
        <Input id="adjust-note" data-testid="adjust-note-input" value={note} onChange={(e) => setNote(e.target.value)} maxLength={100} />
      </div>
      <DialogFooter>
        <Button variant="outline" data-testid="adjust-cancel-button" onClick={onClose}>Batal</Button>
        <Button data-testid="adjust-save-button" disabled={!delta || Number(delta) === 0 || m.isPending} onClick={() => m.mutate()}>
          {m.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Coins className="h-4 w-4" />} Simpan
        </Button>
      </DialogFooter>
    </div>
  );
}

function PasswordChangeForm({ target, onClose }: { target: AdminUser; onClose: () => void }) {
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const change = useMutation({
    mutationFn: () => apiPost<{ ok: boolean }>(`/admin/users/${target.id}/password`, { password }),
    onSuccess: () => {
      toast.success(`Password ${target.username} diganti. Pengguna harus masuk lagi.`);
      onClose();
    },
    onError: (e) => toast.error(errText(e)),
  });

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Minimal 6 karakter. Sesi aktif pengguna akan dicabut dan ia perlu masuk lagi.</p>
      <div className="space-y-1">
        <Label htmlFor="user-new-password">Password baru</Label>
        <Input
          id="user-new-password"
          data-testid="user-new-password-input"
          type="password"
          autoComplete="new-password"
          minLength={6}
          maxLength={72}
          value={password}
          onChange={(event) => setPassword(event.target.value)}
        />
      </div>
      <div className="space-y-1">
        <Label htmlFor="user-confirm-password">Ulangi password baru</Label>
        <Input
          id="user-confirm-password"
          data-testid="user-confirm-password-input"
          type="password"
          autoComplete="new-password"
          minLength={6}
          maxLength={72}
          value={confirmation}
          onChange={(event) => setConfirmation(event.target.value)}
        />
      </div>
      {confirmation && password !== confirmation && (
        <p className="text-sm text-destructive" data-testid="user-password-mismatch">Konfirmasi password belum sama.</p>
      )}
      <DialogFooter>
        <Button variant="outline" data-testid="user-password-cancel" onClick={onClose}>Batal</Button>
        <Button
          data-testid="user-password-save"
          disabled={password.length < 6 || password !== confirmation || change.isPending}
          onClick={() => change.mutate()}
        >
          {change.isPending && <Loader2 className="h-4 w-4 animate-spin" />} Simpan Password
        </Button>
      </DialogFooter>
    </div>
  );
}

function RoleChangeForm({ target, onClose }: { target: AdminUser; onClose: () => void }) {
  const qc = useQueryClient();
  const [role, setRole] = useState<UserRole>(target.role);
  const change = useMutation({
    mutationFn: () => apiPost<AdminUser>(`/admin/users/${target.id}/role`, { role }),
    onSuccess: (updatedUser) => {
      qc.setQueryData<AdminUser[]>(["admin", "users"], (users) =>
        users?.map((user) => (user.id === updatedUser.id ? updatedUser : user)),
      );
      qc.invalidateQueries({ queryKey: ["admin"] });
      toast.success(`Peran ${target.username} sekarang ${role === "admin" ? "Admin" : "Member"}.`);
      onClose();
    },
    onError: (e) => toast.error(errText(e)),
  });

  return (
    <div className="space-y-4">
      <div className="space-y-1">
        <Label htmlFor="user-role-select">Peran akun</Label>
        <select
          id="user-role-select"
          data-testid="user-role-select"
          value={role}
          onChange={(event) => setRole(event.target.value as UserRole)}
          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
        >
          <option value="user">Member</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <p className="text-sm text-muted-foreground">Akun Admin dapat membuka pengaturan dan mengelola pengguna. Minimal satu Admin harus tetap ada.</p>
      <DialogFooter>
        <Button variant="outline" data-testid="user-role-cancel" onClick={onClose}>Batal</Button>
        <Button data-testid="user-role-save" disabled={role === target.role || change.isPending} onClick={() => change.mutate()}>
          {change.isPending && <Loader2 className="h-4 w-4 animate-spin" />} Simpan Peran
        </Button>
      </DialogFooter>
    </div>
  );
}

function UsersTab() {
  const q = useQuery({ queryKey: ["admin", "users"], queryFn: () => apiGet<AdminUser[]>("/admin/users"), refetchInterval: 5000 });
  const [target, setTarget] = useState<AdminUser | null>(null);
  const [passwordTarget, setPasswordTarget] = useState<AdminUser | null>(null);
  const [roleTarget, setRoleTarget] = useState<AdminUser | null>(null);

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto rounded-xl border border-pink-500/15">
        <table className="w-full text-sm" data-testid="admin-users-table">
          <thead>
            <tr className="border-b border-pink-500/15 bg-secondary/50 text-left text-xs uppercase text-muted-foreground">
              <th className="p-3 pr-4">Username</th>
              <th className="p-3 pr-4">Role</th>
              <th className="p-3 pr-4">Saldo Coin</th>
              <th className="p-3 pr-4">Terdaftar</th>
              <th className="p-3">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {(q.data ?? []).map((u) => (
              <tr key={u.id} className="border-b border-pink-500/10 hover:bg-secondary/40">
                <td className="p-3 pr-4 font-bold" data-testid={`admin-user-${u.username}`}>{u.username}</td>
                <td className="p-3 pr-4">{u.role === "admin" ? <Badge>admin</Badge> : <Badge variant="outline">user</Badge>}</td>
                <td className="p-3 pr-4">{formatNumber(u.coins)}</td>
                <td className="p-3 pr-4 text-xs text-muted-foreground">{formatDateTime(u.created_at)}</td>
                <td className="p-3">
                  <div className="flex min-w-64 flex-wrap gap-1.5">
                    <Button size="xs" variant="outline" data-testid={`admin-user-adjust-${u.username}`} onClick={() => setTarget(u)}>
                      <Coins className="h-3.5 w-3.5" /> Atur Coin
                    </Button>
                    <Button size="xs" variant="outline" data-testid={`admin-user-password-${u.username}`} onClick={() => setPasswordTarget(u)}>
                      Ganti Password
                    </Button>
                    <Button size="xs" variant="outline" data-testid={`admin-user-role-${u.username}`} onClick={() => setRoleTarget(u)}>
                      Ubah Peran
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={!!target} onOpenChange={(open) => !open && setTarget(null)}>
        <DialogContent className="sm:max-w-md" data-testid="admin-adjust-dialog">
          <DialogHeader>
            <DialogTitle>Atur Saldo Coin — {target?.username}</DialogTitle>
          </DialogHeader>
          {target && <AdjustDialog target={target} onClose={() => setTarget(null)} />}
        </DialogContent>
      </Dialog>

      <Dialog open={!!passwordTarget} onOpenChange={(open) => !open && setPasswordTarget(null)}>
        <DialogContent className="sm:max-w-md" data-testid="admin-user-password-dialog">
          <DialogHeader>
            <DialogTitle>Ganti Password — {passwordTarget?.username}</DialogTitle>
            <DialogDescription>Password baru tidak ditampilkan lagi setelah disimpan.</DialogDescription>
          </DialogHeader>
          {passwordTarget && <PasswordChangeForm target={passwordTarget} onClose={() => setPasswordTarget(null)} />}
        </DialogContent>
      </Dialog>

      <Dialog open={!!roleTarget} onOpenChange={(open) => !open && setRoleTarget(null)}>
        <DialogContent className="sm:max-w-md" data-testid="admin-user-role-dialog">
          <DialogHeader>
            <DialogTitle>Ubah Peran — {roleTarget?.username}</DialogTitle>
            <DialogDescription>Pilih akses Member atau Admin untuk akun ini.</DialogDescription>
          </DialogHeader>
          {roleTarget && <RoleChangeForm target={roleTarget} onClose={() => setRoleTarget(null)} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ============ SETTINGS ============ */

type PaymentCategory = "bank" | "ewallet" | "qris";

const PAYMENT_CATEGORIES: { id: PaymentCategory; label: string }[] = [
  { id: "bank", label: "Bank" },
  { id: "ewallet", label: "E-Wallet" },
  { id: "qris", label: "QRIS" },
];

function paymentMethodsFor(category: PaymentCategory): readonly string[] {
  if (category === "bank") return BANK_METHODS;
  if (category === "ewallet") return EWALLET_METHODS;
  return ["qris"];
}

function PaymentAccountsEditor({
  accounts,
  onChange,
}: {
  accounts: PaymentAccount[];
  onChange: (accounts: PaymentAccount[]) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [category, setCategory] = useState<PaymentCategory>("bank");
  const [search, setSearch] = useState("");
  const [draft, setDraft] = useState<PaymentAccount | null>(null);

  const startAdd = () => {
    setEditingIndex(null);
    setCategory("bank");
    setSearch("");
    setDraft({ method: "", name: "", number: "" });
    setIsOpen(true);
  };

  const startEdit = (index: number) => {
    const account = accounts[index];
    setEditingIndex(index);
    setCategory(account.method === "qris" ? "qris" : EWALLET_METHODS.includes(account.method as typeof EWALLET_METHODS[number]) ? "ewallet" : "bank");
    setSearch("");
    setDraft({ ...account });
    setIsOpen(true);
  };

  const methods = paymentMethodsFor(category);
  const filteredMethods = methods.filter((method) =>
    PAYMENT_LABELS[method].toLocaleLowerCase("id-ID").includes(search.trim().toLocaleLowerCase("id-ID")),
  );
  const isMethodValid = !!draft && methods.includes(draft.method);

  const chooseCategory = (next: PaymentCategory) => {
    setCategory(next);
    setSearch("");
    setDraft((current) => {
      if (!current) return current;
      const nextMethods = paymentMethodsFor(next);
      const method = nextMethods.includes(current.method) ? current.method : next === "qris" ? "qris" : "";
      return {
        ...current,
        method,
        ...(next === "qris" && !current.name ? { name: "QRIS" } : {}),
        ...(next === "qris" && !current.number ? { number: "Scan kode QRIS" } : {}),
      };
    });
  };

  const saveDraft = () => {
    if (!draft || !isMethodValid || !draft.name.trim() || !draft.number.trim()) return;
    const next = [...accounts];
    if (editingIndex === null) next.push({ ...draft, name: draft.name.trim(), number: draft.number.trim() });
    else next[editingIndex] = { ...draft, name: draft.name.trim(), number: draft.number.trim() };
    onChange(next);
    setIsOpen(false);
  };

  return (
    <>
      <div className="space-y-3" data-testid="settings-accounts-editor">
        <p className="text-xs text-muted-foreground">
          Tambahkan rekening bank dan akun E-Wallet secara terpisah. Cari nama bank atau pilih metode yang tersedia. Perubahan aktif setelah menekan Simpan Pengaturan.
        </p>
        {accounts.length === 0 && (
          <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
            Belum ada metode pembayaran. Tambahkan bank, E-Wallet, atau QRIS.
          </p>
        )}
        {accounts.map((account, index) => {
          const legacyMethod = !MANUAL_METHODS.includes(account.method as typeof MANUAL_METHODS[number]);
          return (
            <div key={`${account.method}-${index}`} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-background/60 p-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-medium">{PAYMENT_LABELS[account.method] ?? account.method}</p>
                  {legacyMethod && <Badge variant="outline" className="text-amber-600">Nonaktif</Badge>}
                </div>
                <p className="truncate text-sm text-muted-foreground">{account.name} · {account.number}</p>
                {legacyMethod && <p className="mt-1 text-xs text-muted-foreground">Metode lama. Edit untuk memilih bank atau E-Wallet yang benar.</p>}
              </div>
              <div className="flex shrink-0 gap-1">
                <Button size="sm" variant="outline" data-testid={`settings-account-edit-${index}`} onClick={() => startEdit(index)}>Edit</Button>
                <Button
                  size="icon-xs"
                  variant="ghost"
                  data-testid={`settings-account-remove-${index}`}
                  aria-label="Hapus metode pembayaran"
                  onClick={() => onChange(accounts.filter((_, itemIndex) => itemIndex !== index))}
                >
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </Button>
              </div>
            </div>
          );
        })}
        <Button size="sm" variant="outline" data-testid="settings-account-add-button" onClick={startAdd}>
          <Plus className="h-4 w-4" /> Tambah Pembayaran
        </Button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg" data-testid="settings-account-dialog">
          <DialogHeader>
            <DialogTitle>{editingIndex === null ? "Tambah Pembayaran" : "Edit Pembayaran"}</DialogTitle>
            <DialogDescription>Pilih jenis pembayaran, lalu cari bank atau E-Wallet yang ingin ditambahkan.</DialogDescription>
          </DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-2" role="group" aria-label="Jenis pembayaran">
                {PAYMENT_CATEGORIES.map((item) => (
                  <Button
                    key={item.id}
                    type="button"
                    variant={category === item.id ? "default" : "outline"}
                    aria-pressed={category === item.id}
                    onClick={() => chooseCategory(item.id)}
                  >
                    {item.label}
                  </Button>
                ))}
              </div>

              <div className="space-y-2">
                {category !== "qris" && (
                  <div className="relative">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      value={search}
                      onChange={(event) => setSearch(event.target.value)}
                      placeholder={category === "bank" ? "Cari nama bank…" : "Cari E-Wallet…"}
                      aria-label={category === "bank" ? "Cari nama bank" : "Cari E-Wallet"}
                      data-testid="settings-account-method-search"
                      className="pl-9"
                    />
                  </div>
                )}
                {draft.method && !isMethodValid && (
                  <p className="text-xs text-amber-600">Metode lama ini tidak tersedia untuk pembayaran baru. Pilih metode yang tercantum di bawah.</p>
                )}
                <div className="grid max-h-44 grid-cols-2 gap-2 overflow-y-auto rounded-lg border border-border p-2 sm:grid-cols-3">
                  {filteredMethods.map((method) => (
                    <Button
                      key={method}
                      type="button"
                      size="sm"
                      variant={draft.method === method ? "default" : "outline"}
                      aria-pressed={draft.method === method}
                      onClick={() => setDraft({ ...draft, method })}
                    >
                      {PAYMENT_LABELS[method]}
                    </Button>
                  ))}
                  {filteredMethods.length === 0 && <p className="col-span-full p-3 text-center text-sm text-muted-foreground">Bank tidak ditemukan.</p>}
                </div>
              </div>

              <div className="space-y-3">
                <div className="space-y-1">
                  <Label htmlFor="payment-account-name">{category === "qris" ? "Nama tampilan" : "Nama pemilik akun"}</Label>
                  <Input
                    id="payment-account-name"
                    value={draft.name}
                    placeholder={category === "qris" ? "QRIS" : "Contoh: Dea Store"}
                    onChange={(event) => setDraft({ ...draft, name: event.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="payment-account-number">{category === "bank" ? "Nomor rekening" : category === "ewallet" ? "Nomor HP / akun" : "Petunjuk pembayaran"}</Label>
                  <Input
                    id="payment-account-number"
                    value={draft.number}
                    placeholder={category === "bank" ? "Masukkan nomor rekening" : category === "ewallet" ? "Masukkan nomor akun" : "Scan kode QRIS"}
                    onChange={(event) => setDraft({ ...draft, number: event.target.value })}
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Batal</Button>
            <Button type="button" disabled={!isMethodValid || !draft?.name.trim() || !draft?.number.trim()} onClick={saveDraft}>
              Simpan Metode
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function SettingsTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["settings"], queryFn: () => apiGet<StoreSettings>("/settings"), refetchInterval: 30000 });
  const waAlertStatus = useQuery({
    queryKey: ["admin", "whatsapp-notification-status"],
    queryFn: () => apiGet<{ configured: boolean; missing: string[] }>("/admin/notification-status"),
  });
  const [form, setForm] = useState<StoreSettings | null>(null);
  const [qrisFile, setQrisFile] = useState<File | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);

  useEffect(() => {
    if (q.data) {
      setForm((current) => current
        ? { ...current, robux_stock_available: q.data!.robux_stock_available, store_open_now: q.data!.store_open_now }
        : q.data!);
    }
  }, [q.data]);

  const save = useMutation({
    mutationFn: () =>
      apiPut<StoreSettings>("/settings", {
        wa_number: form!.wa_number,
        payment_accounts: form!.payment_accounts,
        coin_price_idr_per_100: Number(form!.coin_price_idr_per_100),
        coin_discount_percent: Number(form!.coin_discount_percent),
        min_topup_coins: Number(form!.min_topup_coins),
        announcement: form!.announcement,
        maintenance: form!.maintenance,
        store_name: form!.store_name,
        logo_file_id: form!.logo_file_id,
        hero_title: form!.hero_title,
        hero_subtitle: form!.hero_subtitle,
        store_open: form!.store_open,
        opening_hours_enabled: form!.opening_hours_enabled,
        opens_at: form!.opens_at,
        closes_at: form!.closes_at,
        robux_stock: form!.robux_stock,
        custom_robux_price_per_1000_idr: Number(form!.custom_robux_price_per_1000_idr),
      }),
    onSuccess: (s) => {
      setForm(s);
      qc.invalidateQueries({ queryKey: ["settings"] });
      qc.invalidateQueries({ queryKey: ["admin"] });
      toast.success("Pengaturan disimpan");
    },
    onError: (e) => toast.error(errText(e)),
  });

  const qrisUpload = useMutation({
    mutationFn: () => apiUpload<StoreSettings>("/settings/qris", qrisFile!),
    onSuccess: (s) => {
      setForm(s);
      setQrisFile(null);
      qc.invalidateQueries({ queryKey: ["settings"] });
      toast.success("Gambar QRIS diperbarui");
    },
    onError: (e) => toast.error(errText(e)),
  });

  const logoUpload = useMutation({
    mutationFn: () => apiUpload<StoreSettings>("/settings/logo", logoFile!),
    onSuccess: (s) => {
      setForm(s);
      setLogoFile(null);
      qc.invalidateQueries({ queryKey: ["settings"] });
      toast.success("Logo toko diperbarui");
    },
    onError: (e) => toast.error(errText(e)),
  });

  if (!form) return <p className="py-8 text-center text-sm text-muted-foreground">Memuat pengaturan…</p>;

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card className="border-pink-500/15">
        <CardHeader>
          <CardTitle className="text-base">Pengaturan Toko</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4" data-testid="admin-settings-form">
          <div className="space-y-1">
            <Label htmlFor="set-store-name">Nama toko</Label>
            <Input
              id="set-store-name"
              value={form.store_name}
              maxLength={60}
              onChange={(e) => setForm({ ...form, store_name: e.target.value })}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="set-wa">Nomor WhatsApp CS (format 62…)</Label>
            <Input
              id="set-wa"
              data-testid="settings-wa-input"
              value={form.wa_number}
              onChange={(e) => setForm({ ...form, wa_number: e.target.value.replace(/[^0-9]/g, "") })}
              maxLength={16}
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="set-custom-robux-price">Harga 1.000 Robux (Rp)</Label>
              <Input
                id="set-custom-robux-price"
                data-testid="settings-custom-robux-price-input"
                type="number"
                min={1}
                value={form.custom_robux_price_per_1000_idr}
                onChange={(e) => setForm({ ...form, custom_robux_price_per_1000_idr: Number(e.target.value) })}
              />
              <p className="text-xs text-muted-foreground">Patokan untuk jumlah Robux bebas yang diketik pembeli.</p>
            </div>
            <div className="space-y-1">
              <Label htmlFor="set-rate">Harga 100 Coin (Rp)</Label>
              <Input
                id="set-rate"
                data-testid="settings-rate-input"
                type="number"
                min={1}
                value={form.coin_price_idr_per_100}
                onChange={(e) => setForm({ ...form, coin_price_idr_per_100: Number(e.target.value) })}
              />
              <p className="text-xs text-muted-foreground">Contoh: isi 5000 berarti 100 coin top-up seharga Rp5.000.</p>
            </div>
            <div className="space-y-1">
              <Label htmlFor="set-disc">Diskon Coin (%)</Label>
              <Input
                id="set-disc"
                data-testid="settings-discount-input"
                type="number"
                value={form.coin_discount_percent}
                onChange={(e) => setForm({ ...form, coin_discount_percent: Number(e.target.value) })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="set-min">Min. Top-Up Coin</Label>
              <Input
                id="set-min"
                data-testid="settings-min-topup-input"
                type="number"
                value={form.min_topup_coins}
                onChange={(e) => setForm({ ...form, min_topup_coins: Number(e.target.value) })}
              />
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="set-hero-title">Judul utama beranda</Label>
            <Input
              id="set-hero-title"
              value={form.hero_title}
              maxLength={120}
              onChange={(e) => setForm({ ...form, hero_title: e.target.value })}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="set-hero-subtitle">Deskripsi beranda</Label>
            <Textarea
              id="set-hero-subtitle"
              value={form.hero_subtitle}
              onChange={(e) => setForm({ ...form, hero_subtitle: e.target.value })}
              rows={2}
              maxLength={250}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="set-announce">Pengumuman (tampil di beranda, kosongkan untuk sembunyikan)</Label>
            <Textarea
              id="set-announce"
              data-testid="settings-announcement-input"
              value={form.announcement ?? ""}
              onChange={(e) => setForm({ ...form, announcement: e.target.value || null })}
              rows={2}
              maxLength={200}
            />
          </div>
          <div className="flex items-center gap-2">
            <Checkbox
              id="set-maintenance"
              data-testid="settings-maintenance-checkbox"
              checked={form.maintenance}
              onCheckedChange={(v) => setForm({ ...form, maintenance: v === true })}
            />
            <Label htmlFor="set-maintenance">Mode maintenance (tampilkan peringatan di beranda)</Label>
          </div>
          <div className="space-y-3 rounded-xl border border-pink-500/15 bg-secondary/30 p-4" data-testid="settings-operations">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-heading text-sm font-extrabold">Jam Operasional &amp; Stok</h3>
              <Badge className={form.store_open_now ? "bg-emerald-600 text-white" : "bg-slate-600 text-white"}>
                {form.store_open_now ? "Buka sekarang" : "Tutup sekarang"}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="set-store-open"
                checked={form.store_open}
                onCheckedChange={(v) => setForm({ ...form, store_open: v === true })}
              />
              <Label htmlFor="set-store-open">Toko dibuka untuk pesanan baru</Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="set-hours-enabled"
                checked={form.opening_hours_enabled}
                onCheckedChange={(v) => setForm({ ...form, opening_hours_enabled: v === true })}
              />
              <Label htmlFor="set-hours-enabled">Tutup otomatis di luar jam operasional (WIB)</Label>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="set-opens-at">Buka pukul</Label>
                <Input id="set-opens-at" type="time" value={form.opens_at} onChange={(e) => setForm({ ...form, opens_at: e.target.value })} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="set-closes-at">Tutup pukul</Label>
                <Input id="set-closes-at" type="time" value={form.closes_at} onChange={(e) => setForm({ ...form, closes_at: e.target.value })} />
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="set-robux-stock">Total stok Robux fisik</Label>
              <Input
                id="set-robux-stock"
                type="number"
                min={0}
                value={form.robux_stock ?? ""}
                placeholder="Kosongkan jika tidak melacak stok"
                onChange={(e) => setForm({ ...form, robux_stock: e.target.value === "" ? null : Number(e.target.value) })}
              />
              <p className="text-xs text-muted-foreground">
                Isi stok yang benar-benar kamu punya. Pesanan berbayar dicadangkan, pesanan ditolak mengembalikannya, dan pesanan selesai menguranginya. Kosongkan untuk mematikan pelacakan stok.
              </p>
              {form.robux_stock != null && (
                <p className="text-xs font-semibold text-primary">
                  Status publik: {formatNumber(form.robux_stock_available ?? form.robux_stock)} Robux tersedia
                </p>
              )}
            </div>
          </div>
          <Button data-testid="settings-save-button" disabled={save.isPending} onClick={() => save.mutate()} className="w-full">
            {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />} Simpan Pengaturan
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <Card className="border-pink-500/15">
          <CardHeader>
            <CardTitle className="text-base">Notifikasi Pesanan</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Badge className={waAlertStatus.data?.configured ? "bg-emerald-600 text-white" : "bg-amber-500 text-white"}>
              {waAlertStatus.data?.configured ? "WhatsApp otomatis siap" : "WhatsApp otomatis belum tersambung"}
            </Badge>
            <p className="text-muted-foreground">
              Notifikasi desktop tersedia saat panel admin terbuka. Pengiriman otomatis ke WhatsApp perlu WhatsApp Business Cloud API dan template pemberitahuan yang disetujui.
            </p>
            {!waAlertStatus.data?.configured && waAlertStatus.data?.missing?.length ? (
              <p className="text-xs text-muted-foreground">Pengaturan server yang belum diisi: {waAlertStatus.data.missing.join(", ")}.</p>
            ) : null}
          </CardContent>
        </Card>
        <Card className="border-pink-500/15">
          <CardHeader>
            <CardTitle className="text-base">Logo Toko</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <img
              src={form.logo_file_id ? fileUrl(form.logo_file_id) : "/logo.svg"}
              alt="Pratinjau logo toko"
              className="h-20 w-20 rounded-2xl border border-pink-500/20 bg-card object-contain p-2"
            />
            <Input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setLogoFile(e.target.files?.[0] ?? null)} />
            <p className="text-xs text-muted-foreground">Pilih gambar JPG, PNG, atau WebP maksimal 5 MB.</p>
            <Button size="sm" disabled={!logoFile || logoUpload.isPending} onClick={() => logoUpload.mutate()}>
              {logoUpload.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <PackageIcon className="h-4 w-4" />} Upload Logo
            </Button>
          </CardContent>
        </Card>
        <Card className="border-pink-500/15">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <QrCode className="h-4 w-4 text-primary" /> Gambar QRIS
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {form.qris_image_file_id && (
              <img
                src={fileUrl(form.qris_image_file_id)}
                alt="QRIS saat ini"
                className="h-40 w-40 rounded-lg border border-pink-500/20 object-contain"
                data-testid="settings-qris-preview"
              />
            )}
            <Input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              data-testid="settings-qris-input"
              onChange={(e) => setQrisFile(e.target.files?.[0] ?? null)}
            />
            <Button
              size="sm"
              data-testid="settings-qris-upload-button"
              disabled={!qrisFile || qrisUpload.isPending}
              onClick={() => qrisUpload.mutate()}
            >
              {qrisUpload.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <QrCode className="h-4 w-4" />} Upload QRIS
            </Button>
          </CardContent>
        </Card>

        <Card className="border-pink-500/15">
          <CardHeader>
            <CardTitle className="text-base">Metode Pembayaran</CardTitle>
          </CardHeader>
          <CardContent>
            <PaymentAccountsEditor
              accounts={form.payment_accounts}
              onChange={(payment_accounts) => setForm({ ...form, payment_accounts })}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

/* ============ PAGE ============ */

export default function AdminPage() {
  const [tab, setTab] = useState("dashboard");
  const notifications = useAdminNotifications();
  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="flex items-center gap-2 text-3xl">
          <ShieldAlert className="h-7 w-7 text-primary" /> Panel Admin Dea Store
        </h1>
        <Button size="sm" variant="outline" onClick={notifications.enable} disabled={notifications.permission === "granted"}>
          {notifications.permission === "granted" ? <BellRing className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
          {notifications.permission === "granted" ? "Notifikasi Aktif" : notifications.permission === "denied" ? "Izinkan Notifikasi di Browser" : "Aktifkan Notifikasi"}
        </Button>
      </div>
      <Tabs value={tab} onValueChange={setTab} className="mt-6">
        <TabsList className="grid w-full grid-cols-2 gap-1 group-data-horizontal/tabs:h-auto sm:inline-flex sm:w-fit sm:flex-wrap [&>[data-slot=tabs-trigger]]:h-11 [&>[data-slot=tabs-trigger]]:min-w-0">
          <TabsTrigger value="dashboard" data-testid="admin-tab-dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="orders" data-testid="admin-tab-orders">Pesanan</TabsTrigger>
          <TabsTrigger value="topups" data-testid="admin-tab-topups">Top-Up Coin</TabsTrigger>
          <TabsTrigger value="packages" data-testid="admin-tab-packages">Paket</TabsTrigger>
          <TabsTrigger value="users" data-testid="admin-tab-users">Pengguna</TabsTrigger>
          <TabsTrigger value="community">Komunitas</TabsTrigger>
          <TabsTrigger value="settings" data-testid="admin-tab-settings">Pengaturan</TabsTrigger>
        </TabsList>
        <TabsContent value="dashboard"><DashboardTab /></TabsContent>
        <TabsContent value="orders"><OrdersTab /></TabsContent>
        <TabsContent value="topups"><TopupsTab /></TabsContent>
        <TabsContent value="packages"><PackagesTab /></TabsContent>
        <TabsContent value="users"><UsersTab /></TabsContent>
        <TabsContent value="community"><CommunityAdminTab /></TabsContent>
        <TabsContent value="settings"><SettingsTab /></TabsContent>
      </Tabs>
    </div>
  );
}
