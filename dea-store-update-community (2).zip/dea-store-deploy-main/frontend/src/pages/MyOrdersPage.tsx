import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Package, Search } from "lucide-react";
import { apiGet } from "@/lib/api";
import type { Order } from "@/lib/types";
import { formatDateTime, formatIDR, formatNumber, PAYMENT_LABELS } from "@/lib/format";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { OrderStatusBadge } from "@/components/StatusBadge";

export default function MyOrdersPage() {
  const ordersQuery = useQuery({
    queryKey: ["orders", "mine"],
    queryFn: () => apiGet<Order[]>("/orders/mine"),
    refetchInterval: 4000,
  });
  const { data: orders, isLoading } = ordersQuery;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <h1 className="text-3xl">Pesanan Saya</h1>
      <p className="mt-1 text-sm text-muted-foreground">Semua top up Robux yang pernah kamu buat di Dea Store.</p>

      <Card className="mt-6 border-pink-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Package className="h-5 w-5 text-primary" /> Riwayat Pesanan
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading && <p className="py-6 text-center text-sm text-muted-foreground">Memuat…</p>}
          {ordersQuery.isError && <p role="alert" className="py-4 text-sm text-destructive">Riwayat belum dapat dimuat. <button type="button" className="min-h-11 font-bold underline" onClick={() => ordersQuery.refetch()}>Coba lagi</button></p>}
          {orders && orders.length === 0 && (
            <div className="flex flex-col items-center gap-3 py-10 text-center" data-testid="my-orders-empty">
              <p className="text-sm text-muted-foreground">Belum ada pesanan — yuk mulai top up pertamamu!</p>
              <Link to="/order" data-testid="my-orders-cta" className={buttonVariants({ size: "sm" })}>
                <Search className="h-4 w-4" /> Top Up Sekarang
              </Link>
            </div>
          )}
          {orders && orders.length > 0 && (
            <>
            <div className="space-y-3 sm:hidden" data-testid="my-orders-cards">
              {orders.map((o) => (
                <article key={o.id} className="space-y-3 rounded-xl border border-pink-500/20 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-mono font-bold">{o.code}</p>
                    <OrderStatusBadge status={o.status} />
                  </div>
                  <p className="break-words font-semibold">{o.roblox_username}</p>
                  <p className="text-sm">{formatNumber(o.robux)} Robux · {o.total_coins != null ? `${formatNumber(o.total_coins)} coin` : formatIDR(o.total_idr)}</p>
                  <p className="text-xs text-muted-foreground">{PAYMENT_LABELS[o.payment_method] ?? o.payment_method} · {formatDateTime(o.created_at)}</p>
                  <Link to={`/track?code=${encodeURIComponent(o.code)}`} className={`${buttonVariants({ variant: "outline" })} min-h-11 w-full`}>
                    {o.status === "menunggu_pembayaran" ? "Lanjut Bayar" : "Lihat Status Pesanan"}
                  </Link>
                </article>
              ))}
            </div>
            <div className="hidden overflow-x-auto sm:block">
              <table className="w-full text-sm" data-testid="my-orders-table">
                <thead>
                  <tr className="border-b border-pink-500/15 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="py-2 pr-4">Kode</th>
                    <th className="py-2 pr-4">Username Roblox</th>
                    <th className="py-2 pr-4">Robux</th>
                    <th className="py-2 pr-4">Total</th>
                    <th className="py-2 pr-4">Metode</th>
                    <th className="py-2 pr-4">Status</th>
                    <th className="py-2">Tanggal</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((o) => (
                    <tr key={o.id} className="border-b border-pink-500/10" data-testid={`my-order-row-${o.code}`}>
                      <td className="py-2 pr-4">
                        <Link to={`/track?code=${o.code}`} className="font-mono font-bold text-primary hover:underline">
                          {o.code}
                        </Link>
                      </td>
                      <td className="py-2 pr-4 font-semibold">{o.roblox_username}</td>
                      <td className="py-2 pr-4">{formatNumber(o.robux)}</td>
                      <td className="py-2 pr-4">
                        {o.total_coins != null ? `${formatNumber(o.total_coins)} coin` : formatIDR(o.total_idr)}
                      </td>
                      <td className="py-2 pr-4">{PAYMENT_LABELS[o.payment_method] ?? o.payment_method}</td>
                      <td className="py-2 pr-4"><OrderStatusBadge status={o.status} /></td>
                      <td className="py-2 text-xs text-muted-foreground">{formatDateTime(o.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
