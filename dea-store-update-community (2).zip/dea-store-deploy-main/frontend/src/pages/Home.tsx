import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import {
  BadgePercent,
  CheckCircle2,
  Clock3,
  ClipboardCheck,
  Coins,
  Headset,
  Search,
  ShieldCheck,
  Sparkles,
  UserRoundCheck,
  Wallet,
  Zap,
} from "lucide-react";
import { apiGet } from "@/lib/api";
import type { Package, StoreSettings } from "@/lib/types";
import { formatIDR, formatNumber, MANUAL_METHODS, PAYMENT_LABELS, waLink } from "@/lib/format";
import PackageCard from "@/components/PackageCard";
import RobloxDetector from "@/components/RobloxDetector";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const STEPS = [
  { icon: UserRoundCheck, title: "1. Deteksi Username", desc: "Masukkan username Roblox — avatar & ID akun langsung terdeteksi otomatis." },
  { icon: ClipboardCheck, title: "2. Pilih Paket", desc: "Pilih jumlah Robux yang sesuai. Rincian harga muncul sebelum pesanan dibuat." },
  { icon: Wallet, title: "3. Bayar", desc: "Pilih metode pembayaran yang tersedia atau gunakan saldo coin akunmu." },
  { icon: Zap, title: "4. Pantau Status", desc: "Simpan kode pesanan untuk melihat pembaruan proses kapan saja." },
];

export default function Home() {
  const navigate = useNavigate();
  const [checkUser, setCheckUser] = useState("");
  const { data: packages, isLoading: pkgLoading } = useQuery({
    queryKey: ["packages"],
    queryFn: () => apiGet<Package[]>("/packages"),
    refetchInterval: 10000,
  });
  const { data: settings } = useQuery({
    queryKey: ["settings"],
    queryFn: () => apiGet<StoreSettings>("/settings"),
    refetchInterval: 10000,
  });

  const discount = settings?.coin_discount_percent ?? 10;
  const coinPricePer100 = settings?.coin_price_idr_per_100 ?? 110;
  const configuredMethods = MANUAL_METHODS.filter((method) =>
    (settings?.payment_accounts ?? []).some((account) => account.method === method),
  );
  const csLink = settings?.wa_number
    ? waLink(settings.wa_number, "Halo, saya mau bertanya tentang layanan Dea Store.")
    : null;

  return (
    <div className="bg-dotgrid">
      {settings?.announcement && (
        <div
          className="bg-gradient-to-r from-pink-600 via-rose-500 to-pink-600 px-4 py-2 text-center text-sm font-semibold text-white"
          data-testid="announcement-bar"
        >
          {settings.announcement}
        </div>
      )}

      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-2 px-4 pt-4" data-testid="store-status-bar">
        <Badge className={!settings ? "bg-muted text-muted-foreground" : settings.store_open_now ? "bg-emerald-600 text-white" : "bg-slate-600 text-white"}>
          {!settings ? "Memuat status toko…" : settings.store_open_now ? "Toko sedang buka" : "Toko sedang tutup"}
        </Badge>
        {settings?.opening_hours_enabled && (
          <span className="inline-flex items-center gap-1.5 text-sm text-muted-foreground">
            <Clock3 className="h-4 w-4" /> Jam {settings.opens_at}–{settings.closes_at} WIB
          </span>
        )}
        {settings?.robux_stock_available != null ? (
          <span className="rounded-full border border-pink-500/20 bg-card px-3 py-1 text-sm font-semibold text-muted-foreground">
            Stok {formatNumber(settings.robux_stock_available)} Robux
          </span>
        ) : settings ? (
          <span className="rounded-full border border-pink-500/20 bg-card px-3 py-1 text-sm text-muted-foreground">
            Stok dikonfirmasi saat pesanan
          </span>
        ) : null}
      </div>

      {/* HERO */}
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 lg:grid-cols-2 lg:py-16">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <span className="inline-flex items-center gap-2 rounded-full border border-pink-500/30 bg-primary/5 px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary">
            <span className="flex h-2 w-2">
              <span className="absolute h-2 w-2 animate-pulse-beacon rounded-full bg-emerald-500" />
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
            </span>
            Deteksi Username Aktif
          </span>
          <h1 className="mt-4 text-4xl leading-tight sm:text-5xl">
            <span className="text-gradient-pink">{settings?.hero_title ?? "Top Up Robux Murah & Instan"}</span>
          </h1>
          <p className="mt-4 max-w-md text-base font-medium text-muted-foreground sm:text-lg">
            {settings?.hero_subtitle ?? "Cek username, pilih paket, lalu pesan dengan mudah."}
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/order" data-testid="hero-cta-order" className={buttonVariants({ size: "lg" })}>
              <Sparkles className="h-4 w-4" /> Top Up Sekarang
            </Link>
            <Link to="/track" data-testid="hero-cta-track" className={buttonVariants({ variant: "outline", size: "lg" })}>
              <Search className="h-4 w-4" /> Cek Pesanan
            </Link>
          </div>
          <div className="mt-8 grid max-w-md grid-cols-3 gap-3" data-testid="hero-stats">
            {[
              { v: "Aman", l: "Username saja" },
              { v: "Mudah", l: "Lacak pesanan" },
              { v: "Fleksibel", l: "Saldo coin" },
            ].map((s) => (
              <div key={s.l} className="rounded-xl border border-pink-500/15 bg-card/80 p-3 text-center">
                <p className="font-heading text-lg font-extrabold text-primary">{s.v}</p>
                <p className="text-xs text-muted-foreground">{s.l}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="space-y-4"
        >
          <Card className="glow-pink border-pink-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <UserRoundCheck className="h-5 w-5 text-primary" /> Cek Username Roblox
              </CardTitle>
              <CardDescription>Ketik username — avatar akun langsung muncul kalau akunnya ada.</CardDescription>
            </CardHeader>
            <CardContent>
              <RobloxDetector value={checkUser} onChange={setCheckUser} />
            </CardContent>
          </Card>
          <img
            src="/hero.png"
            alt="Dea Store — top up Robux"
            className="animate-float-slow mx-auto w-full max-w-md rounded-2xl border border-pink-500/20 shadow-xl shadow-pink-500/20"
            data-testid="hero-image"
          />
        </motion.div>
      </section>

      {/* PACKAGES */}
      <section className="mx-auto max-w-6xl px-4 py-10" id="paket">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-2xl sm:text-3xl">Pilih Paket Robux</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Pilih jumlah Robux yang kamu perlukan. Harga terbaru ditampilkan sebelum membuat pesanan.
            </p>
          </div>
          <Badge variant="outline" className="gap-1 border-amber-300 bg-amber-100 text-amber-800 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-300">
            <BadgePercent className="h-3.5 w-3.5" /> Diskon {discount}% bayar pakai Coin
          </Badge>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5" data-testid="package-grid">
          {pkgLoading &&
            Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="h-32 animate-pulse rounded-2xl bg-pink-200/50 dark:bg-pink-500/10" />
            ))}
          {!pkgLoading &&
            (packages ?? []).map((pkg, i) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.04, 0.4), duration: 0.35 }}
              >
                <PackageCard
                  pkg={pkg}
                  coinPrice={Math.ceil(pkg.price_idr * (100 - discount) / coinPricePer100)}
                  onSelect={(p) => navigate(`/order?robux=${p.robux}`)}
                />
              </motion.div>
            ))}
          {!pkgLoading && (packages ?? []).length === 0 && (
            <p className="col-span-full py-8 text-center text-sm text-muted-foreground" data-testid="package-empty">
              Paket sedang tidak tersedia — coba muat ulang sebentar lagi.
            </p>
          )}
        </div>
      </section>

      {/* COIN PROMO */}
      <section className="mx-auto max-w-6xl px-4 py-6">
        <div className="glow-pink flex flex-col items-start justify-between gap-4 rounded-2xl bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500 p-6 text-white sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <Coins className="h-10 w-10" />
            <div>
              <h2 className="text-xl sm:text-2xl">Bayar pakai Saldo Coin, hemat {discount}%</h2>
              <p className="text-sm text-white/85">
                Setiap 100 coin bernilai {formatIDR(coinPricePer100)} saat top-up. Harga dan diskon coin dikelola dari pengaturan toko.
              </p>
            </div>
          </div>
          <Link to="/register" data-testid="coin-promo-cta" className="rounded-full bg-white px-5 py-2.5 text-sm font-extrabold text-pink-600 transition-transform hover:scale-105">
            Daftar &amp; Top-Up Coin
          </Link>
        </div>
      </section>

      {/* STEPS */}
      <section className="mx-auto max-w-6xl px-4 py-10">
        <h2 className="text-center text-2xl sm:text-3xl">Cara Top Up di Dea Store</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((s) => (
            <Card key={s.title} className="border-pink-500/15 transition-transform hover:-translate-y-1">
              <CardContent className="p-5">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10">
                  <s.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="mt-3 text-base">{s.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* PAYMENTS + WHY */}
      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="border-pink-500/15">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Wallet className="h-5 w-5 text-primary" /> Metode Pembayaran
              </CardTitle>
              <CardDescription>Upload bukti pembayaran + konfirmasi via WhatsApp, atau bayar instan pakai coin.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2" data-testid="payment-methods-list">
              {configuredMethods.map((m) => (
                <Badge key={m} variant="outline" className="border-pink-500/25 px-3 py-1.5 text-sm">
                  {PAYMENT_LABELS[m]}
                </Badge>
              ))}
              {configuredMethods.length === 0 && <p className="text-sm text-muted-foreground">Metode transfer belum disiapkan. Pilih saldo coin atau hubungi CS.</p>}
              <Badge className="bg-amber-500 px-3 py-1.5 text-sm text-white">Saldo Coin (Diskon {discount}%)</Badge>
            </CardContent>
          </Card>
          <Card className="border-pink-500/15">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <ShieldCheck className="h-5 w-5 text-primary" /> Kenapa Dea Store?
              </CardTitle>
              <CardDescription>Aman, cepat, dan diawasi teknologi anti-penipuan.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { icon: ShieldCheck, t: "Deteksi Bukti Palsu", d: "Setiap bukti pembayaran discan AI + deteksi gambar duplikat otomatis." },
                { icon: CheckCircle2, t: "Harga transparan", d: "Total pembayaran terlihat sebelum kamu membuat pesanan." },
                { icon: Headset, t: "Bantuan CS", d: "Hubungi customer service melalui WhatsApp jika nomor CS sudah disetel." },
              ].map((f) => (
                <div key={f.t} className="flex gap-3">
                  <f.icon className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                  <div>
                    <p className="text-sm font-bold">{f.t}</p>
                    <p className="text-sm text-muted-foreground">{f.d}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </section>

      {csLink ? (
        <a
          href={csLink}
          target="_blank"
          rel="noreferrer"
          aria-label="Hubungi Customer Service melalui WhatsApp"
          className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 rounded-full bg-emerald-600 px-5 py-3 text-sm font-extrabold text-white shadow-xl shadow-emerald-900/20 transition hover:-translate-y-0.5 hover:bg-emerald-700"
          data-testid="home-cs-button"
        >
          <Headset className="h-5 w-5" /> Chat CS
        </a>
      ) : (
        <div
          title="Admin dapat mengaktifkan CS dengan mengisi nomor WhatsApp di Pengaturan."
          className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 rounded-full border border-emerald-600/20 bg-card px-5 py-3 text-sm font-bold text-muted-foreground shadow-lg"
          data-testid="home-cs-button"
        >
          <Headset className="h-5 w-5" /> CS belum diatur
        </div>
      )}
    </div>
  );
}
