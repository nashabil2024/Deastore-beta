import { useState } from "react";
import { Link, Navigate, useNavigate, useSearchParams } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { BadgePercent, Loader2, UserRoundPlus } from "lucide-react";
import { ApiError, apiPost } from "@/lib/api";
import type { SessionUser } from "@/lib/types";
import { useBeginSession, useSession } from "@/lib/session";
import SessionUnavailable from "@/components/SessionUnavailable";
import { Button } from "@/components/ui/button";
import { AuthShell } from "@/pages/LoginPage";

export default function RegisterPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const beginSession = useBeginSession();
  const { data: currentUser, isLoading: sessionLoading, isError: sessionError, isFetching: sessionFetching, refetch: refetchSession } = useSession();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");

  const register = useMutation({
    mutationFn: () => apiPost<SessionUser>("/auth/register", { username, password, referral_code: searchParams.get("ref") }),
    onSuccess: (u) => {
      beginSession(u);
      toast.success(`Akun ${u.username} berhasil dibuat! Saldo coin: 0`);
      navigate("/dashboard", { replace: true });
    },
    onError: (e) => {
      const detail = e instanceof ApiError ? e.detail() : null;
      if (detail === "Username sudah terdaftar") {
        toast.info("Akun ini sudah terdaftar. Silakan masuk untuk lanjut ke Saldo Coin.");
        navigate("/login?next=%2Fdashboard", { replace: true });
        return;
      }
      toast.error(detail ?? "Pendaftaran gagal");
    },
  });

  if (sessionLoading) {
    return <div className="flex min-h-[50vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }
  if (sessionError && !currentUser) {
    return <SessionUnavailable onRetry={() => { void refetchSession(); }} isRetrying={sessionFetching} />;
  }
  if (currentUser) {
    return <Navigate to={currentUser.role === "admin" ? "/admin" : "/dashboard"} replace />;
  }

  return (
    <AuthShell title="Daftar Dea Store" description="Gratis — dapatkan saldo coin & diskon 10% semua paket Robux.">
      <form
        className="space-y-4"
        data-testid="register-form"
        onSubmit={(e) => {
          e.preventDefault();
          if (password !== confirm) {
            toast.error("Konfirmasi password tidak sama");
            return;
          }
          register.mutate();
        }}
      >
        <div className="space-y-2">
          <label className="text-sm font-bold" htmlFor="register-username">Username</label>
          <input
            id="register-username"
            data-testid="register-username-input"
            className="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            minLength={3}
            maxLength={24}
            pattern="[A-Za-z0-9_.]+"
            autoComplete="username"
          />
          <p className="text-xs text-muted-foreground">3–24 karakter, huruf/angka/titik/garis bawah.</p>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-bold" htmlFor="register-password">Password</label>
          <input
            id="register-password"
            data-testid="register-password-input"
            type="password"
            className="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
            autoComplete="new-password"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-bold" htmlFor="register-confirm">Ulangi Password</label>
          <input
            id="register-confirm"
            data-testid="register-confirm-input"
            type="password"
            className="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            required
            minLength={6}
            autoComplete="new-password"
          />
        </div>
        <Button type="submit" className="w-full" size="lg" data-testid="register-submit-button" disabled={register.isPending}>
          {register.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserRoundPlus className="h-4 w-4" />}
          Daftar Sekarang
        </Button>
        <p className="text-center text-sm text-muted-foreground">
          Sudah punya akun?{" "}
          <Link to="/login" data-testid="register-to-login-link" className="font-bold text-primary hover:underline">
            Masuk di sini
          </Link>
        </p>
        <div className="flex items-center gap-2 rounded-xl bg-amber-500/10 p-3 text-xs font-semibold text-amber-700 dark:text-amber-300">
          <BadgePercent className="h-4 w-4 shrink-0" />
          Khusus member: bayar Robux pakai Saldo Coin = hemat 10% setiap transaksi.
        </div>
      </form>
    </AuthShell>
  );
}
