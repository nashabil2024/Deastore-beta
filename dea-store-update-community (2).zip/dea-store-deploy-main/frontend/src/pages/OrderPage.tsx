import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  CircleAlert,
  Coins,
  Loader2,
  LogIn,
  MessageCircle,
  PartyPopper,
  ReceiptText,
  Send,
  ShieldCheck,
} from "lucide-react";
import { ApiError, apiGet, apiPost, apiUpload } from "@/lib/api";
import type { Order, Package, StoreSettings } from "@/lib/types";
import {
  formatIDR,
  formatNumber,
  MANUAL_METHODS,
  orderWaText,
  PAYMENT_LABELS,
  waLink,
} from "@/lib/format";
import { useSession } from "@/lib/session";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import PackageCard from "@/components/PackageCard";
import RobloxDetector from "@/components/RobloxDetector";
import ProofUploader from "@/components/ProofUploader";
import CopyText from "@/components/CopyText";
import PaymentInstructions from "@/components/PaymentInstructions";
import { OrderStatusBadge } from "@/components/StatusBadge";
import { cn } from "@/lib/utils";

export default function OrderPage() {
  const [params] = useSearchParams();
  const qc = useQueryClient();
  const { data: user } = useSession();

  const [username, setUsername] = useState("");
  const [robux, setRobux] = useState<number | null>(Number(params.get("robux")) || null);
  const [customRobux, setCustomRobux] = useState("");
  const [method, setMethod] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [voucherCode, setVoucherCode] = useState("");
  const [order, setOrder] = useState<Order | null>(null);
  const [file, setFile] = useState<File | null>(null);

  const { data: packages } = useQuery({ queryKey: ["packages"], queryFn: () => apiGet<Package[]>("/packages"), refetchInterval: 10000 });
  const { data: settings } = useQuery({ queryKey: ["settings"], queryFn: () => apiGet<StoreSettings>("/settings"), refetchInterval: 10000 });

  const discount = method === "coin" ? (settings?.coin_discount_percent ?? 10) : 0;
  const availableManualMethods = MANUAL_METHODS.filter((m) =>
    m === "qris"
      ? Boolean(settings?.qris_image_file_id || (settings?.payment_accounts ?? []).some((account) => account.method === m))
      : (settings?.payment_accounts ?? []).some((account) => account.method === m),
  );
  const selectedPkg = packages?.find((p) => p.robux === robux) ?? null;
  const customRate = settings?.custom_robux_price_per_1000_idr ?? 150000;
  const totalIdr = selectedPkg?.price_idr ?? (robux ? Math.ceil(robux * customRate / 1000) : 0);
  const totalCoins = robux && method === "coin"
    ? Math.ceil(totalIdr * (100 - discount) / (settings?.coin_price_idr_per_100 ?? 110))
    : null;
  const insufficientCoins = method === "coin" && user != null && totalCoins != null && user.coins < totalCoins;
  const methodUnavailable = method !== null && method !== "coin" && !availableManualMethods.includes(method as typeof availableManualMethods[number]);
  const usernameOk = username.trim().length >= 3;
  const storeClosed = settings?.store_open_now === false;
  const stockUnavailable = robux != null && settings?.robux_stock_available != null && settings.robux_stock_available < robux;
  const ewalletMethods = availableManualMethods.filter((m) => ["dana", "gopay", "ovo", "shopeepay"].includes(m));
  const bankMethods = availableManualMethods.filter((m) => !["qris", "dana", "gopay", "ovo", "shopeepay"].includes(m));

  const createOrder = useMutation({
    mutationFn: () =>
      apiPost<Order>("/orders", {
        roblox_username: username.trim(),
        robux,
        payment_method: method,
        note: note.trim() || null,
        voucher_code: voucherCode.trim() || null,
      }),
    onSuccess: async (o) => {
      setOrder(o);
      setFile(null);
      qc.invalidateQueries({ queryKey: ["me"] });
      toast.success(`Pesanan ${o.code} berhasil dibuat!`);
      window.scrollTo({ top: 0, behavior: "smooth" });
    },
    onError: (e) =>
      toast.error(e instanceof ApiError ? (e.detail() ?? "Gagal membuat pesanan") : "Gagal membuat pesanan"),
  });

  const uploadProof = useMutation({
    mutationFn: () => apiUpload<Order>(`/orders/${order!.code}/proof`, file!),
    onSuccess: (o) => {
      setOrder(o);
      toast.success("Bukti pembayaran terkirim! Admin akan segera memverifikasi.");
    },
    onError: (e) =>
      toast.error(e instanceof ApiError ? (e.detail() ?? "Gagal mengunggah bukti") : "Gagal mengunggah bukti"),
  });

  /* ---------- RESULT PANEL (after order created) ---------- */
  if (order) {
    const isCoin = order.payment_method === "coin";
    const wa = waLink(
      settings?.wa_number ?? "",
      orderWaText(order.code, order.roblox_username, order.robux, formatIDR(order.total_idr), order.payment_method),
    );
    return (
      <div className="mx-auto max-w-3xl px-4 py-10">
        <Card className="border-pink-500/20" data-testid="order-success-panel">
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <CardTitle className="flex flex-wrap items-center gap-2 text-xl">
                <ReceiptText className="h-5 w-5 text-primary" /> Pesanan #{order.code} <CopyText value={order.code} label="Salin kode pesanan" />
              </CardTitle>
              <OrderStatusBadge status={order.status} />
            </div>
            <CardDescription>
              {order.roblox_username} · {formatNumber(order.robux)} Robux ·{" "}
              {order.total_coins != null
                ? `${formatNumber(order.total_coins)} Coin (diskon ${order.discount_percent}%)`
                : formatIDR(order.total_idr)}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {isCoin ? (
              <div className="flex items-start gap-3 rounded-xl border border-emerald-300/60 bg-emerald-50 p-4 dark:border-emerald-500/40 dark:bg-emerald-500/10">
                <PartyPopper className="mt-0.5 h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <p className="font-bold text-emerald-800 dark:text-emerald-300">Pembayaran coin berhasil!</p>
                  <p className="text-sm text-emerald-700 dark:text-emerald-400">
                    {formatNumber(order.total_coins ?? 0)} coin telah dipotong dari saldo. Pesananmu langsung
                    diproses admin — pantau statusnya di halaman cek pesanan.
                  </p>
                </div>
              </div>
            ) : order.status === "menunggu_pembayaran" ? (
              <>
                <PaymentInstructions settings={settings} method={order.payment_method} total={order.total_idr} />
                <div className="space-y-3">
                  <p className="text-sm font-bold">
                    2. Upload bukti pembayaran <span className="text-destructive">*</span>
                  </p>
                  <ProofUploader file={file} onFile={setFile} disabled={uploadProof.isPending} />
                  <Button
                    data-testid="btn-upload-proof"
                    disabled={!file || uploadProof.isPending}
                    onClick={() => uploadProof.mutate()}
                    className="w-full"
                  >
                    {uploadProof.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    Saya Sudah Bayar — Kirim Bukti
                  </Button>
                </div>
              </>
            ) : (
              <div className="rounded-xl border border-sky-300/60 bg-sky-50 p-4 text-sm font-semibold text-sky-800 dark:border-sky-500/40 dark:bg-sky-500/10 dark:text-sky-300">
                Bukti pembayaran sudah diterima dan sedang diverifikasi admin.
              </div>
            )}

            {!isCoin && settings?.wa_number && (
              <a
                href={wa}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="btn-wa-confirm"
                className={cn(buttonVariants({ variant: "outline" }), "w-full whitespace-normal text-center border-emerald-500 text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300 dark:hover:bg-emerald-500/10")}
              >
                <MessageCircle className="h-4 w-4" /> Butuh bantuan? Chat CS via WhatsApp
              </a>
            )}

            <div className="flex flex-wrap gap-2">
              <Link to={`/track?code=${order.code}`} data-testid="track-order-link" className={buttonVariants({ variant: "secondary" })}>
                Lacak Pesanan
              </Link>
              <Button
                variant="ghost"
                data-testid="order-again-button"
                onClick={() => {
                  setOrder(null);
                  setMethod(null);
                  setRobux(null);
                  setCustomRobux("");
                  setNote("");
                }}
              >
                Top Up Lagi
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  /* ---------- WIZARD ---------- */
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-3xl">Top Up Robux</h1>
      <p className="mt-1 text-sm text-muted-foreground">Isi 3 langkah cepat — Robux masuk via username Roblox.</p>
      {storeClosed && (
        <div className="mt-4 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm font-semibold text-amber-800 dark:text-amber-300" data-testid="order-store-closed">
          Toko sedang tutup. {settings?.opening_hours_enabled ? `Jam buka ${settings.opens_at}–${settings.closes_at} WIB.` : "Pesanan baru akan dibuka kembali oleh admin."}
        </div>
      )}
      {stockUnavailable && (
        <div className="mt-4 rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm font-semibold text-red-700 dark:text-red-300" data-testid="order-stock-unavailable">
          Stok tersisa {formatNumber(settings?.robux_stock_available ?? 0)} Robux, belum cukup untuk paket ini.
        </div>
      )}

      {/* STEP 1 */}
      <Card className="mt-6 border-pink-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-extrabold text-primary-foreground">1</span>
            Username Roblox
          </CardTitle>
          <CardDescription>Akun terdeteksi otomatis lewat API resmi Roblox.</CardDescription>
        </CardHeader>
        <CardContent>
          <RobloxDetector value={username} onChange={setUsername} />
        </CardContent>
      </Card>

      {/* STEP 2 */}
      <Card className="mt-4 border-pink-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-extrabold text-primary-foreground">2</span>
            Pilih Paket Robux
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4" data-testid="order-package-grid">
            {(packages ?? []).map((pkg) => (
              <PackageCard
                key={pkg.id}
                pkg={pkg}
                selected={pkg.robux === robux}
                coinPrice={Math.ceil(
                  pkg.price_idr * (100 - (settings?.coin_discount_percent ?? 10)) /
                    (settings?.coin_price_idr_per_100 ?? 110),
                )}
                onSelect={(p) => {
                  setCustomRobux("");
                  setRobux(p.robux);
                }}
              />
            ))}
            {!packages && Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-32 animate-pulse rounded-2xl bg-pink-200/50 dark:bg-pink-500/10" />
            ))}
          </div>
          <div className="mt-4 rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-4" data-testid="custom-robux-card">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="font-bold">Mau jumlah bebas?</p>
                <p className="text-sm text-muted-foreground">Ketik jumlah Robux yang diinginkan. Harga mengikuti patokan {formatIDR(customRate)} per 1.000 Robux.</p>
              </div>
              <div className="w-full sm:w-56">
                <label htmlFor="custom-robux" className="mb-1 block text-xs font-bold text-muted-foreground">Jumlah Robux</label>
                <Input
                  id="custom-robux"
                  data-testid="custom-robux-input"
                  inputMode="numeric"
                  type="number"
                  min={1}
                  max={1000000}
                  placeholder="Contoh: 1250"
                  value={customRobux}
                  onChange={(e) => {
                    const value = e.target.value;
                    setCustomRobux(value);
                    const amount = Number(value);
                    setRobux(Number.isInteger(amount) && amount > 0 && amount <= 1000000 ? amount : null);
                  }}
                />
              </div>
            </div>
            {customRobux && robux && !selectedPkg && (
              <p className="mt-3 rounded-xl bg-card px-3 py-2 text-sm font-semibold text-primary">
                {formatNumber(robux)} Robux = {formatIDR(totalIdr)}
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* STEP 3 */}
      <Card className="mt-4 border-pink-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-extrabold text-primary-foreground">3</span>
            Metode Pembayaran
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3" data-testid="payment-method-grid">
            {availableManualMethods.includes("qris") && (
              <button
                type="button"
                data-testid="payment-method-card-qris"
                aria-pressed={method === "qris"}
                onClick={() => setMethod("qris")}
                className={cn(
                  "flex w-full flex-col items-start justify-between gap-3 rounded-2xl border p-4 sm:flex-row sm:items-center text-left transition-all active:scale-[0.99]",
                  method === "qris" ? "border-primary bg-primary/5 ring-2 ring-primary/40" : "border-pink-500/20 bg-card",
                )}
              >
                <span>
                  <span className="block text-base font-extrabold">QRIS — paling gampang</span>
                  <span className="mt-0.5 block text-xs text-muted-foreground">Scan pakai DANA, GoPay, ShopeePay, atau m-banking.</span>
                </span>
                <Badge className="bg-emerald-600 text-white">Rekomendasi</Badge>
              </button>
            )}

            {ewalletMethods.length > 0 && (
              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">E-wallet</p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {ewalletMethods.map((m) => (
                    <button key={m} type="button" data-testid={`payment-method-card-${m}`} aria-pressed={method === m} onClick={() => setMethod(m)} className={cn("min-h-12 rounded-xl border px-3 py-2 text-sm font-bold transition-all", method === m ? "border-primary bg-primary/5 ring-2 ring-primary/40" : "border-pink-500/20 bg-card")}>{PAYMENT_LABELS[m]}</button>
                  ))}
                </div>
              </div>
            )}

            {bankMethods.length > 0 && (
              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">Transfer bank</p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {bankMethods.map((m) => (
                    <button key={m} type="button" data-testid={`payment-method-card-${m}`} aria-pressed={method === m} onClick={() => setMethod(m)} className={cn("min-h-12 rounded-xl border px-3 py-2 text-sm font-bold transition-all", method === m ? "border-primary bg-primary/5 ring-2 ring-primary/40" : "border-pink-500/20 bg-card")}>{PAYMENT_LABELS[m]}</button>
                  ))}
                </div>
              </div>
            )}

            {availableManualMethods.length === 0 && (
              <p className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 text-sm text-muted-foreground">
                Pembayaran manual belum diatur. Pilih Saldo Coin atau hubungi CS.
              </p>
            )}
            <button
              type="button"
              data-testid="payment-method-card-coin"
              aria-pressed={method === "coin"}
              onClick={() => setMethod("coin")}
              className={cn(
                "relative flex w-full flex-col items-start justify-between gap-3 rounded-2xl border p-4 sm:flex-row sm:items-center text-left transition-all active:scale-[0.99]",
                method === "coin" ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/40" : "border-amber-500/40 bg-card",
              )}
            >
              <span className="flex items-center gap-2 text-sm font-bold"><Coins className="h-5 w-5 text-amber-600 dark:text-amber-400" /> Bayar pakai Saldo Coin {!user && <span className="text-xs font-medium text-muted-foreground">(perlu login)</span>}</span>
              <Badge className="bg-amber-500 text-white">Hemat {settings?.coin_discount_percent ?? 10}%</Badge>
            </button>
          </div>

          {user && <div className="space-y-1">
            <label className="text-sm font-semibold" htmlFor="order-voucher">Kode Voucher (opsional)</label>
            <Input id="order-voucher" value={voucherCode} onChange={(e) => setVoucherCode(e.target.value.toUpperCase())} placeholder="Masukkan kode voucher" maxLength={24} />
            <p className="text-xs text-muted-foreground">Lihat voucher aktif di halaman Member Club.</p>
          </div>}
          <div>
            <Textarea
              data-testid="order-note-input"
              placeholder="Catatan untuk admin (opsional) — cth: kirim malam ya kak"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              maxLength={300}
              rows={2}
            />
          </div>

          {/* SUMMARY */}
          <div className="rounded-xl border border-pink-500/20 bg-secondary p-4 text-sm" data-testid="order-summary">
            <div className="flex justify-between gap-3 py-0.5 [&>span:last-child]:min-w-0 [&>span:last-child]:break-words [&>span:last-child]:text-right">
              <span className="text-muted-foreground">Username</span>
              <span className="font-bold">{usernameOk ? username.trim() : "—"}</span>
            </div>
            <div className="flex justify-between gap-3 py-0.5 [&>span:last-child]:min-w-0 [&>span:last-child]:break-words [&>span:last-child]:text-right">
              <span className="text-muted-foreground">Paket</span>
              <span className="font-bold">{robux ? `${formatNumber(robux)} Robux` : "—"}</span>
            </div>
            <div className="flex justify-between gap-3 py-0.5 [&>span:last-child]:min-w-0 [&>span:last-child]:break-words [&>span:last-child]:text-right">
              <span className="text-muted-foreground">Metode</span>
              <span className="font-bold">{method ? PAYMENT_LABELS[method] : "—"}</span>
            </div>
            <div className="mt-2 flex justify-between border-t border-pink-500/15 pt-2 text-base">
              <span className="font-bold">Total</span>
              <span className="font-extrabold text-primary" data-testid="order-summary-total">
                {method === "coin"
                  ? totalCoins != null
                    ? `${formatNumber(totalCoins)} Coin`
                    : "—"
                  : robux
                    ? formatIDR(totalIdr)
                    : "—"}
              </span>
            </div>
            {method === "coin" && robux && (
              <p className="mt-1 text-right text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                Harga normal {formatIDR(totalIdr)} — hemat {discount}% dengan coin!
              </p>
            )}
          </div>

          {method === "coin" && !user && (
            <div className="flex flex-col items-start gap-2 rounded-xl border border-amber-300/60 bg-amber-50 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-amber-500/40 dark:bg-amber-500/10">
              <p className="flex items-center gap-2 text-sm font-bold text-amber-800 dark:text-amber-300">
                <CircleAlert className="h-4 w-4" /> Pembayaran coin hanya untuk akun terdaftar.
              </p>
              <div className="flex gap-2">
                <Link to="/login?next=/order" data-testid="coin-login-cta" className={buttonVariants({ size: "sm" })}>
                  <LogIn className="h-4 w-4" /> Masuk
                </Link>
                <Link to="/register?next=/order" data-testid="coin-register-cta" className={buttonVariants({ variant: "outline", size: "sm" })}>
                  Daftar
                </Link>
              </div>
            </div>
          )}

          {method === "coin" && user && totalCoins != null && (
            <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3 text-sm" data-testid="order-coin-balance">
              <p>Saldo kamu: <strong>{formatNumber(user.coins)} coin</strong></p>
              {insufficientCoins ? (
                <p className="mt-1 text-destructive">Kurang {formatNumber(totalCoins - user.coins)} coin. <Link to="/dashboard" className="font-bold underline">Top-Up Coin</Link> atau pilih pembayaran lain.</p>
              ) : <p className="mt-1 text-muted-foreground">Sisa setelah bayar: {formatNumber(user.coins - totalCoins)} coin.</p>}
            </div>
          )}
          {methodUnavailable && <p role="alert" className="text-sm text-destructive">Metode ini sedang tidak tersedia. Pilih metode pembayaran lain.</p>}

          <Button
            data-testid="btn-submit-order"
            size="lg"
            className="w-full"
            disabled={!usernameOk || !robux || !method || createOrder.isPending || (method === "coin" && !user) || !settings || storeClosed || stockUnavailable || insufficientCoins || methodUnavailable}
            onClick={() => createOrder.mutate()}
          >
            {createOrder.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
            {storeClosed ? "Toko Tutup" : stockUnavailable ? "Stok Tidak Cukup" : insufficientCoins ? "Saldo Coin Kurang" : "Buat Pesanan"}
          </Button>
          <p className="text-center text-xs text-muted-foreground">
            Pastikan username benar sebelum membayar — Robux yang terkirim ke akun salah tidak dapat ditarik.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
